# Task 19 — Monte Carlo: the (Nearly) Ideal Weak-Scaling Workload

Each rank simulates a constant number of paths. Non-zero α comes from:

| Source | Serial/overhead time | Scaling with P |
|---|---|---|
| PRNG seed management | stream creation. Naïve sequential seeding by rank 0: O(P). With counter-based RNGs (Philox, Threefry), or jump-ahead/skip-ahead in a splittable generator: **O(1)** per rank (parallel) | O(P) → O(1) |
| Reduction of partial sums/variances | tree reduction: ⌈log₂P⌉ steps × t_lvl | **O(log P)** |
| Output serialisation (single file/histogram, checkpoint) | fixed t_out; grows if per-rank data is gathered (O(P)) | O(1) or O(P) |
| Load imbalance (variable path lengths, e.g. barrier options, rare-event) | max over ranks − mean | grows slowly ∼ √(2 ln P)·σ |
| Start-up (job launch, MPI_Init) | O(log P)–O(P) | |

## Model of α(P) with a tree reduction

T = 10 s of parallel compute (constant), t_seed = 2 ms, t_out = 20 ms, t_lvl = 50 µs per tree level.

α(P) = [t_seed + t_out + t_lvl·⌈log₂P⌉] / [T + t_seed + t_out + t_lvl·⌈log₂P⌉]

S(P) = P − α(P)(P−1). (`calculations/compute_all.py`)

| P | tree-reduction time | α(P) | S(P) | E(P) |
|---|---|---|---|---|
| 16 | 0.20 ms | 0.002215 | 15.97 | 0.9979 |
| 256 | 0.40 ms | 0.002235 | 255.43 | 0.9978 |
| 4,096 | 0.60 ms | 0.002255 | 4,086.8 | 0.9977 |
| 65,536 | 0.80 ms | 0.002275 | 65,386.9 | 0.9977 |
| 1,048,576 | 1.00 ms | 0.002295 | 1,046,170 | 0.9977 |

**Impact of the tree:** doubling P 16× adds only 0.2 ms; α rises by 2×10⁻⁵ per ×16 in P. The reduction changes S(P) at the 4th significant digit even at 10⁶ ranks. In contrast, a flat (linear) gather at rank 0, cost t_lvl·(P−1):

| P | flat reduction | α | S | E |
|---|---|---|---|---|
| 256 | 12.75 ms | 0.00346 | 255.12 | 0.9966 |
| 4,096 | 204.75 ms | 0.0222 | 4,005.2 | 0.9778 |
| 65,536 | 3,277 ms | 0.2481 | 49,280 | 0.7520 |

so the algorithmic structure of the reduction (O(log P) vs O(P)) is the difference between near-ideal and 25 % loss at 65k ranks.

## Further points
* The fixed constants (output, seeding) dominate α: α ≈ 0.0022 is almost entirely t_out; parallel/asynchronous I/O reduces it.
* Statistical accuracy improves as 1/√(kP) — weak scaling buys accuracy, exactly Gustafson's "bigger problem in the same time" interpretation.
* Reproducibility: tree order fixes floating-point summation order, giving deterministic results for a given P (but different across P); use compensated summation if bitwise stability across P matters.
* Model values (t_lvl, t_out) are assumptions, not measurements.
