# Task 24 — Hardware Audit and Empirical-vs-Theoretical Discrepancy

Plot: `plots/scaling_comparison.png` / `.pdf` (curves: ideal, Gustafson fit, measured ± SE, Amdahl with the same serial fraction). Companion: `plots/weak_efficiency.png`.

## 1. Machine used (as reported inside the VM by `lscpu`, `free`, `nproc`)

| Item | Value |
|---|---|
| CPU | Intel Xeon @ 2.30 GHz (family 6, model 173; AVX-512, AMX flags present) |
| Visible hardware threads | **2** (1 socket, 2 cores, 1 thread/core) |
| Hypervisor | KVM full virtualisation (cloud VM) |
| L1d | 96 KiB total = 48 KiB/core; L1i 128 KiB total = 64 KiB/core |
| L2 | 4 MiB total = 2 MiB/core |
| L3 | 504 MiB reported (host's shared L3; not exclusively available to the VM) |
| NUMA | 1 node visible to the guest |
| RAM | ≈ 7–8 GiB |
| Memory channels | **Not observable** inside the VM (the hypervisor hides the host DIMM layout) |
| OS / software | Linux 6.x, Python 3.11, NumPy 2.5.3, multiprocessing (fork) |

This is *not* a many-core node. If your assignment requires a real multi-core machine, re-run `benchmarks/weak_scale_bench/weak_bench.py` on your own hardware (see README) and replace `results.csv`; `fit_gustafson.py` and `make_plots.py` adapt automatically and you should paste your own `lscpu` output into this section.

## 2. Measured results (5 runs per configuration)

| P | wall mean (s) | wall std (s) | S(P) mean ± std | weak eff. T(1)/T(P) | status |
|---|---|---|---|---|---|
| 1 | 0.879 | 0.063 | 0.998 ± 0.072 | 1.000 | |
| 2 | 0.853 | 0.004 | 1.996 ± 0.010 | 1.030 | = hardware threads |
| 3 | 1.301 | 0.028 | 1.947 ± 0.042 | 0.676 | oversubscribed |
| 4 | 1.945 | 0.052 | 1.729 ± 0.046 | 0.452 | oversubscribed |
| 8 | 4.334 | 0.206 | 1.543 ± 0.070 | 0.203 | oversubscribed |

Measured baseline serial fraction at P = 1: s₁ = 0.0445 s, w₁ = 0.829 s ⇒ α(P=1) = 0.0509.

Fitted α (least squares through the origin on P − S = α(P−1)):
* all P > 1 points: **α = 0.859 ± 0.088** — meaningless as a *serial fraction*: it absorbs oversubscription loss;
* P ≤ 2 only: α = 0.0038 from a **single** point (no standard error) — consistent with near-ideal scaling but statistically weak.

## 3. Interpretation

1. **P = 1 → 2:** S = 1.996 (ideal 2 − 0.05 = 1.95 expected for α = 0.0509). Measured scaled speedup is slightly *better* than the baseline serial-fraction prediction, and the weak efficiency 1.03 exceeds 1: the P = 1 wall time has a 7 % standard deviation (first-run warm-up, hypervisor noise), so the 3 % "super-efficiency" is within noise. Conclusion: Gustafson's linear model is validated *only within the real hardware limit*.
2. **P > 2:** the machine physically has two cores, so S(P) ≤ 2 by construction; adding processes only adds time slicing, context switches and cache contention. Predicted time under ideal time-slicing is T(P) ≈ T(1)·P/2 (P = 8 → ≈ 3.5 s); measured 4.33 s, i.e. ≈ 24 % extra overhead for context switching, 8 processes' start-up/reduction, and cache/memory-bandwidth contention (each worker streams chunks of 10⁶ doubles ≈ 8 MB per temporary array, which does not fit in a 2 MiB L2).
3. **Amdahl on the same α = 0.0509** (dashed) drops below the Gustafson line but the oversubscribed measurements fall below *both*: neither law models running more workers than cores.

## 4. Sources of deviation (what a real many-core machine would show)

| Effect | In this VM | On a real many-core server |
|---|---|---|
| Thermal throttling / turbo | not observable (guest sees no sensors; frequency fixed at the nominal 2.3 GHz by the hypervisor) | all-core turbo is lower than single-core turbo ⇒ per-core speed drops with P ⇒ apparent α rises by a few % |
| NUMA boundaries | 1 node visible | cross-socket threads pay 1.3–2× memory latency, bandwidth limited by inter-socket links; first-touch placement matters |
| Memory bandwidth | shared with other tenants | saturates at fewer cores than the core count (memory-bound kernels stop scaling) |
| Shared caches | L3 shared with unknown tenants | L3 contention reduces per-core efficiency |
| SMT | none (1 thread/core) | 2 hardware threads per core share execution units ⇒ scaling beyond the physical-core count yields ≈ 1.2–1.3×, not 2× |
| OS noise/steal time | hypervisor steal likely | jitter amplifies at barriers |

## 5. Limitations (honest summary)

* Only P ≤ 2 are valid weak-scaling points; 3 of 5 thread counts are oversubscribed (flagged in `results.csv`, column `oversubscribed`) to satisfy "at least 5 distinct thread counts".
* The empirical serial fraction is dominated by the benchmark design (a deliberately fixed parent-side serial phase, ≈ 5 % at P = 1).
* Frequency scaling, NUMA effects and memory-channel counts could not be measured here and are discussed from general knowledge, not observation.
