# Task 18 — N-Body Scaling: All-Pairs O(N²) vs Barnes–Hut O(N log N)

## Fixed-time scaling law

Let c = cost of one unit of interaction work, and T = fixed time per iteration on P processors.

| Method | Parallel work | Fixed-time condition | N(P) |
|---|---|---|---|
| Direct all-pairs | c N²/P | cN²/P = T | **N = √(TP/c) ∝ P^{1/2}** |
| Barnes–Hut | c N ln N / P | cN ln N / P = T | N ≈ (TP/c)/ln(TP/c) ∝ **P / log P** |

So the particle count may be grown only by √P under direct summation but almost by P under the tree code (Gustafson's G(P)=P is approached by the tree code, ≈ P/log P; direct all-pairs has G(P) = N²-law ⇒ N ∝ √P).

## Serial/parallel ratio

Suppose a serial (non-parallelised) part of the iteration scales with the particle count, σ(N) = a·N (e.g. output of positions, global bookkeeping, a serial tree-top build, particle redistribution on one rank) with a = 5 ns/particle; c = 1 ns; T = 1 s (`compute_all.py`).

| P | N (all-pairs) | α_all-pairs = σ/(σ+T) | N (Barnes–Hut) | α_BH |
|---|---|---|---|---|
| 1 | 3.2×10⁴ | 0.00016 | 5.6×10⁷ | 0.219 |
| 16 | 1.3×10⁵ | 0.00063 | 7.8×10⁸ | 0.796 |
| 256 | 5.1×10⁵ | 0.0025 | 1.1×10¹⁰ | 0.982 |
| 4,096 | 2.0×10⁶ | 0.0100 | 1.6×10¹¹ | 0.9987 |
| 65,536 | 8.1×10⁶ | 0.0389 | 2.3×10¹² | 0.9999 |

## Interpretation

1. **Direct method:** the parallel part is constant (fixed time) while the serial O(N) part grows ∝ √P, hence α ∝ √P: slowly rising (0.016 % → 3.9 %). Gustafson's constant-α premise holds approximately up to ~10⁴ processes; efficiency ≈ 1 − α(P) remains high. The method has a *large* parallel-to-serial ratio because its work is super-linear in N.
2. **Barnes–Hut:** each particle needs only ~log N work, so the fixed-time problem is huge (N ∝ P/log P) and **any** O(N) serial component (or O(N) communication per process) becomes dominant: α → 1. The efficiency of tree codes therefore relies on parallelising *everything*: tree construction (parallel sort along space-filling curves), load-balancing/domain decomposition, I/O. With every O(N) step distributed (cost aN/P), α stays constant and the tree code scales weakly like Gustafson.
3. Lesson: algorithms with *lower* complexity have *less* parallel work per datum, so the fixed-time problem is larger and the serial/parallel ratio is more sensitive to O(N) serial parts. The faster algorithm is harder to scale, but yields more science per core-hour — compare at equal accuracy, not equal N.

Assumptions (explicit): illustrative constants (c = 1 ns, a = 5 ns) and fixed-time T = 1 s; the *shape* (√P vs P/log P) is the result, not the exact digits.
