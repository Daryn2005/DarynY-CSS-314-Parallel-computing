# Task 20 — Why Graph Analytics Resists Gustafson-Style Weak Scaling

Compared with dense linear algebra (regular, high arithmetic intensity, surface/volume communication that is constant per process — Tasks 16, 17), BFS and PageRank on power-law graphs violate almost every premise of Gustafson's law.

## 1. Work cannot be partitioned evenly

* **Skewed degree distribution** (P(d) ∝ d^{−γ}, γ ≈ 2–3): a few hub vertices own a huge fraction of edges. With vertex-based partitioning, one rank may hold orders of magnitude more edges than another; time = max over ranks, not the mean ⇒ a large, *growing* effective serial fraction.
* **BFS frontier imbalance:** the frontier size varies by orders of magnitude from level to level (explosive in the middle levels of a small-world graph, tiny at the ends); the work per level is data-dependent, so static load balancing is impossible.

## 2. Communication does not have a bounded surface-to-volume ratio

* Power-law graphs have no good small cuts: with a random/hashed partition the fraction of edges that cross partitions is ≈ (P−1)/P → 1. Communication volume per process is Θ(edges per process) — *not* a lower-order surface term as in a 3-D stencil (n² vs n³).
* Communication is all-to-all-like (frontier expansion/scatter of updates); bisection bandwidth, not per-link bandwidth, bounds the speed (as in Task 13 case B).
* Messages are tiny and irregular (fine-grained), so latency and message rate dominate, not bandwidth.

## 3. Memory access is irregular

* Arithmetic intensity is ≈ 0 flop/byte: performance is limited by random-access memory latency/bandwidth and by cache/TLB misses, not by cores. Adding cores per node saturates memory channels (cf. Task 24).
* Memory and caches cannot hide latency by blocking, as in GEMM.

## 4. Synchronisation grows with the graph

* BFS requires a global barrier/all-reduce per level; the number of levels ≈ diameter ≈ O(log N) for small-world graphs, so the *synchronisation count grows with the problem* (slowly): the fixed-time premise breaks mildly.
* PageRank iteration counts are roughly independent of N, but each iteration has an all-to-all exchange and a global convergence reduction.
* Asynchronous variants exchange determinism for fewer barriers but add redundant work and nondeterminism.

## 5. Defining "weak scaling" is itself ambiguous

For graphs, one can scale vertices (N ∝ P) with fixed average degree (Graph500 does this: scale S+1 per doubling of P), but edges/vertex, diameter, hub sizes and cut fraction change with the generator and N, so "constant work per process" is not constant *time*; per-process hub-load grows with N for power-law distributions (the largest degree grows ≈ N^{1/(γ−1)}).

## 6. Consequences & mitigations

| Problem | Mitigation |
|---|---|
| Degree skew | 2-D (edge) partitioning, vertex delegation of hubs (e.g. delegates in Graph500 entries) |
| Frontier imbalance | work-stealing, direction-optimising (top-down/bottom-up) BFS to cut redundant edge checks |
| Fine-grained messages | message coalescing/aggregation, routing through process grids |
| Latency-bound memory | prefetch, multithreading (e.g. Cray XMT-style), compressed formats |

## Verdict

Regular dense linear algebra and stencils have α(P) ≈ constant and per-process communication ≈ constant (Gustafson-compliant). Graph analytics has α(P) growing with P (imbalance, global synchronisation) and communication volume per process ≈ constant *fraction of work*, i.e. a high communication-to-computation ratio. Typical results show weak-scaling efficiencies falling well below 50 % at large scale, and Graph500 rankings are expressed in traversed edges per second (TEPS) rather than flop/s precisely because they are bandwidth- and latency-bound.
