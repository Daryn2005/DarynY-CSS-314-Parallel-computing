# Task 17 — 7-Point 3-D Stencil: Surface-to-Volume Scaling

## Model

Global domain N³ decomposed over P processes in a 3-D Cartesian grid; each process owns a cube of side n = N/P^{1/3}.

* Computation per step per process: ≈ 8 n³ flops (7 loads, 1 store: Θ(n³)).
* Halo exchange per step per process: 6 faces × n² points (one layer for a 7-point stencil) = **6n² words**.
* Communication-to-computation ratio per process: **ρ = 6n²/n³ = 6/n.**

## Weak scaling (Gustafson): n fixed

Work grows by P ⇒ N³ = P·n³ ⇒ N = n P^{1/3} and the local cube is unchanged:

ρ_weak = 6/n = **constant**, independent of P.

Therefore per-process compute time and halo time stay constant — fixed wall time. The total surface (communication volume) grows ∝ P, but **per-process** communication is constant, and nearest-neighbour messages use disjoint links. This is why stencil codes are the poster-child for Gustafson scaling (the nCUBE codes of Task 05).

## Strong scaling (Amdahl): N fixed

n = N/P^{1/3} ⇒ ρ_strong = 6P^{1/3}/N, which grows as P^{1/3} (degrades).

## Numbers

Weak: n = 128 ⇒ ρ = 6/128 = 0.04688 for every P (1 → 4096; global N = 128 … 2048).

Strong: N = 1024:

| P | local n | ρ = 6/n |
|---|---|---|
| 1 | 1,024 | 0.00586 |
| 8 | 512 | 0.01172 |
| 64 | 256 | 0.02344 |
| 512 | 128 | 0.04688 |
| 4,096 | 64 | 0.09375 |

Note that the strong-scaled run at P = 512 has exactly the weak-scaled local size.

## Conclusion and caveats

Under weak scaling the communication-to-computation ratio **neither improves nor degrades**: it stays at 6/n. (It "improves" only relative to strong scaling.) Caveats that make real codes deviate: (1) latency/message-rate (constant per step, fine), (2) global reductions for convergence checks or time-step control (∝ log P), (3) network contention beyond the physical topology, (4) OS noise/imbalance amplified by synchronisation at scale.
