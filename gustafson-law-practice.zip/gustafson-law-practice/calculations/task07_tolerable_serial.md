# Task 07 — Maximum Tolerable Serial Fraction

Given: P = 8,192 cores, required S(P) ≥ 7,500.

## Derivation

S(P) = P − α(P−1) ≥ S_min

⇒ α(P−1) ≤ P − S_min

⇒ **α_max = (P − S_min)/(P − 1)**

## Numbers

α_max = (8192 − 7500)/(8192 − 1) = 692/8191 = **0.084483** (8.448 %)

Check: S = 8192 − 0.0844830·8191 = 8192 − 692.000 = 7500.000 ✓.

Corresponding minimum efficiency: E = 7500/8192 = 0.91553 (91.55 %).

## Remarks

* For large P, α_max ≈ 1 − S_min/P = 1 − E_min (here 0.08447 vs. exact 0.08448): the speedup target is really an efficiency target, E_min ≥ 91.55 %.
* In terms of absolute time: if the parallel run lasts T seconds, serial sections may occupy at most 8.448 % ≈ 0.0845·T.
* The equivalent uniprocessor serial fraction of the scaled problem is s₁ = α/(α+(1−α)P) = 0.08448/(0.08448 + 0.91552·8192) ≈ 1.13×10⁻⁵.
