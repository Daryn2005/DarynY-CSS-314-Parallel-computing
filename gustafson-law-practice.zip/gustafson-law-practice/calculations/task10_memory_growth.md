# Task 10 — Memory Growth vs. Weak Scaling

## Formulation

* Weak scaling: W(P) = P·W(1); the grid has N³ points with b bytes per point (state variables × bytes × time levels).
* Aggregate memory M(P) = c·P with c = 32 GiB per node (the cap). The N-point grid must fit:

  b·N³ ≤ M(P) = P·32 GiB  ⇒  **N_max(P) = ( P·32·2³⁰ / b )^{1/3} = N_max(1)·P^{1/3}**

* A per-node cube of side n = N_max(1) = (32 GiB/b)^{1/3}; the global cube has side n·P^{1/3} (equal for P that are perfect cubes, e.g. 64 → 4n, 512 → 8n).

## Numbers (GiB = 2³⁰ B)

| Bytes/point (b) | Interpretation | n (1 node) | N_max, 64 nodes | N_max, 512 nodes |
|---|---|---|---|---|
| 8 | one double array | 1,625 | **6,501** | **13,003** |
| 40 | 5 double fields | 950 | **3,802** | **7,604** |
| 80 | 5 fields × 2 time levels | 754 | **3,017** | **6,035** |

Totals: 64 nodes → 2,048 GiB; 512 nodes → 16,384 GiB.

(Example, b = 8: 64 nodes: points = 2,048·2³⁰/8 = 2.749×10¹¹, cube-root = 6,501. 512 nodes: 2.199×10¹², cube-root = 13,003.)

## Observations

* Linear growth of memory (∝P) means the grid side grows as P^{1/3}: 64× nodes → 4× side (and 64× points); 512× nodes → 8× side.
* Memory only caps the problem; Gustafson additionally needs the *time* to stay constant. For explicit 3-D solvers with CFL, steps ∝ N ⇒ run time ∝ P^{1/3} (Task 13), so the memory-limited problem is solvable only in P^{1/3}× more time — Sun–Ni’s regime (Task 11).
* Practical headroom: halo cells, buffers and OS/MPI memory typically take 10–20 % of the node, scaling N_max down by ≈ 4–7 % (cube-root of 0.8–0.9).
