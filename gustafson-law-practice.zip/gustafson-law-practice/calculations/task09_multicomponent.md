# Task 09 — Multi-Component Workload

Phases (share of total **parallel** execution time, so Gustafson's frame is correct):

| Phase | Share | Serial? |
|---|---|---|
| A: initial disk I/O + parameter broadcast | 2 % | Yes — treated as serial |
| B: boundary message-passing synchronisation | 6 % | **Assumption: treated as serial/non-scaling** |
| C: core domain flux computation | 92 % | No — perfectly parallel |

## Aggregate serial fraction

α = 0.02 + 0.06 = **0.08** (8 %).

Justification of B: synchronisation time does not shrink when more processors share the *same* per-process work, and in the scaled problem each process still waits for the slowest neighbour; counting it as non-parallelisable (a pessimistic, safe assumption) gives the conservative answer. (If B is instead taken to scale perfectly, α = 0.02; results shown below as sensitivity.)

## Scaled speedup

S(P) = P − 0.08(P−1);  E = S/P

| P | α(P−1) | S(P) | E(P) |
|---|---|---|---|
| 512 | 0.08·511 = 40.88 | **471.12** | 0.9202 |
| 2,048 | 0.08·2047 = 163.76 | **1,884.24** | 0.9200 |

## Sensitivity (only phase A serial, α = 0.02)

| P | S(P) | E |
|---|---|---|
| 512 | 501.78 | 0.9800 |
| 2,048 | 2,007.06 | 0.9800 |

## Composite analysis

* Phase C (92 %) sets the plateau efficiency 1−α = 0.92.
* Phase B contributes 75 % of the loss (6/8); optimising the synchronisation (overlapping, asynchronous halo exchange) is worth ≈ +6 pts of efficiency, three times more than optimising I/O (parallel I/O could gain up to +2 pts).
* Uniprocessor-equivalent serial fraction: s₁ = 0.08/(0.08+0.92P) = 1.70×10⁻⁴ (P = 512), 4.2×10⁻⁵ (P = 2048). Amdahl evaluated with s₁ reproduces the Gustafson values (471.12, 1,884.24) — verified in `compute_all.py`.
* Caveat: in practice phase B generally grows with P (Task 12), so 8 % is a lower bound of α at scale.
