# Task 06 — Parametric Speedup, α = 0.04

Formulas: S(P) = P − α(P−1) = P − 0.04(P−1);  E(P) = S/P.  (Reproduce: `python3 calculations/compute_all.py`)

| P | α(P−1) | S(P) | E(P) | Efficiency loss 1−E |
|---|---|---|---|---|
| 16 | 0.04·15 = 0.60 | **15.4000** | 0.962500 | 3.7500 % |
| 64 | 0.04·63 = 2.52 | **61.4800** | 0.960625 | 3.9375 % |
| 256 | 0.04·255 = 10.20 | **245.8000** | 0.960156 | 3.9844 % |
| 1,024 | 0.04·1023 = 40.92 | **983.0800** | 0.960039 | 3.9961 % |
| 4,096 | 0.04·4095 = 163.80 | **3,932.2000** | 0.960010 | 3.9990 % |
| 16,384 | 0.04·16383 = 655.32 | **15,728.6800** | 0.960002 | 3.9998 % |

## Evaluation

* The sheet asks how efficiency "degrades" as P grows exponentially: it barely does. E(P) = 0.96 + 0.04/P falls from 0.9625 to 0.9600 over a 1,024-fold increase in P; it converges to 1−α = 0.96 (Task 04). Each 4× increase in P changes E by less than 0.0019 after P = 64.
* The *absolute* loss P − S = α(P−1) grows linearly (0.6 → 655 lost "processor equivalents"), but the *relative* loss is bounded by α.
* Even at 16,384 cores the machine is 96 % utilised — if (and only if) α stays at 4 %, i.e. the serial time does not grow with the problem and no extra communication/imbalance appears (Tasks 12, 13).
* For contrast, Amdahl with s = 0.04 caps at 25× no matter what.
