# Task 16 — Dense GEMM under Fixed-Time Weak Scaling

## Derivation

Work: W(N) = 2N³ flops. Memory: 3N² words (A, B, C).

Fixed parallel time T on P processors, each doing flops at rate r, and ignoring communication (ideal):

T = W(N)/(P·r) = 2N³/(P r) = constant = T₁ = 2N₁³/r

⇒ N³ = P·N₁³ ⇒ **N(P) = N₁·P^{1/3}.**

Consequences:
* Work per processor constant, total work ∝ P ✓ (Gustafson's G(P) = P).
* Total memory 3N² ∝ P^{2/3} grows **slower** than P: memory per processor ∝ P^{−1/3} — GEMM does not run out of memory in weak scaling (opposite of Task 10’s limit; the memory-bound regime gives N ∝ P^{1/2} and G = P^{3/2}, Task 11).
* Communication per processor for a 2-D algorithm (SUMMA) ∝ N²/√P = N₁²P^{2/3}/√P = N₁²P^{1/6} grows slowly, so strictly the runtime grows ∝ P^{1/6} unless one uses 3-D/2.5-D algorithms, which move N²/P^{2/3} = N₁² (constant) per processor.

## Scaling targets (N₁ = 2000 on one core, 16 Gflop per core)

| P | N = 2000·P^{1/3} | Total flops 2N³ | Flops per core | Memory per core (3 N² × 8 B / P) |
|---|---|---|---|---|
| 1 | 2,000 | 1.60×10¹⁰ | 1.6×10¹⁰ | 96.0 MB |
| 8 | 4,000 | 1.28×10¹¹ | 1.6×10¹⁰ | 48.0 MB |
| 64 | 8,000 | 1.02×10¹² | 1.6×10¹⁰ | 24.0 MB |
| 512 | 16,000 | 8.19×10¹² | 1.6×10¹⁰ | 12.0 MB |
| 4,096 | 32,000 | 6.55×10¹³ | 1.6×10¹⁰ | 6.0 MB |
| 32,768 | 64,000 | 5.24×10¹⁴ | 1.6×10¹⁰ | 3.0 MB |

Rule: multiply P by 8 ⇒ double N.
