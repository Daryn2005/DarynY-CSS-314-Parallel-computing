# Task 08 — Amdahl vs. Gustafson at s = α = 0.08, P = 128

## Amdahl (fixed-size)

S_A = 1 / (s + (1−s)/P) = 1 / (0.08 + 0.92/128) = 1 / (0.08 + 0.0071875) = 1 / 0.0871875 = **11.4695**

## Gustafson (scaled)

S_G = P − α(P−1) = 128 − 0.08·127 = 128 − 10.16 = **117.84**

## Discrepancy

| Measure | Value |
|---|---|
| Absolute difference S_G − S_A | 106.37 |
| Ratio S_G / S_A | **10.27×** |
| Gustafson above Amdahl: (S_G − S_A)/S_A | **+927.4 %** |
| Amdahl below Gustafson: (S_G − S_A)/S_G | −90.27 % |

## Divergence with P

| P | S_Amdahl | S_Gustafson | ratio |
|---|---|---|---|
| 2 | 1.852 | 1.920 | 1.04 |
| 8 | 5.128 | 7.440 | 1.45 |
| 32 | 9.195 | 29.52 | 3.21 |
| 128 | 11.470 | 117.84 | 10.27 |
| 512 | 12.225 | 471.12 | 38.5 |
| 2,048 | 12.430 | 1,884.2 | 151.6 |
| 8,192 | 12.483 | 7,536.7 | 603.8 |
| 65,536 | 12.498 | 60,293 | 4,824 |

## Why they diverge

* Amdahl is bounded by 1/s = 12.5 (the curve is asymptotically flat: dS_A/dP → 0). Gustafson is linear with slope 1−α = 0.92 (dS_G/dP = 0.92 forever).
* The ratio S_G/S_A grows linearly in P for large P: ≈ α(1−α)P = 0.0736·P (9.4 at P = 128 from this leading term; the exact value 10.27 includes lower-order terms).
* There is **no cross-over point**: the curves coincide only at P = 1 (S = 1) and S_G ≥ S_A for all P ≥ 1 when s = α. They are not competing predictions of the same experiment: with identical numeric value 0.08, s is a uniprocessor fraction of a fixed problem; α is a parallel-machine fraction of a scaled problem (Task 03). The equivalent uniprocessor serial fraction for the Gustafson scenario at P = 128 is s₁ = 0.08/(0.08+0.92·128) = 6.8×10⁻⁴.
