#!/usr/bin/env python3
"""Reproduces every numeric result in calculations/*.md and analysis/*.md.
Run:  python3 calculations/compute_all.py
"""
import math

def gus(P, a):   return P - a * (P - 1)
def amd(P, s):   return 1.0 / (s + (1 - s) / P)

print("== TASK 06: alpha = 0.04 ==")
for P in (16, 64, 256, 1024, 4096, 16384):
    S = gus(P, 0.04)
    print(f"P={P:6d}  S={S:12.4f}  E={S/P:.6f}  1-E={1-S/P:.6f}")

print("\n== TASK 07: P=8192, S>=7500 ==")
P, Smin = 8192, 7500
amax = (P - Smin) / (P - 1)
print(f"alpha_max = {P-Smin}/{P-1} = {amax:.8f}  ({amax*100:.4f}%)")
print(f"check S = {gus(P, amax):.6f}  E = {gus(P, amax)/P:.6f}")

print("\n== TASK 08: s = 0.08, P = 128 ==")
sa = amd(128, 0.08); sg = gus(128, 0.08)
print(f"Amdahl = {sa:.4f}  Gustafson = {sg:.4f}")
print(f"abs diff = {sg-sa:.4f}; (G-A)/A = {100*(sg-sa)/sa:.2f}%; (G-A)/G = {100*(sg-sa)/sg:.2f}%; ratio G/A = {sg/sa:.3f}")
for P in (2, 8, 32, 128, 512, 2048, 8192, 65536):
    print(f"  P={P:6d} Amdahl={amd(P,0.08):8.4f} Gustafson={gus(P,0.08):12.4f} ratio={gus(P,0.08)/amd(P,0.08):9.2f}")
print(f"Amdahl ceiling 1/s = {1/0.08:.2f}")

print("\n== TASK 09: alpha = 0.02 + 0.06 = 0.08 ==")
for P in (512, 2048):
    S = gus(P, 0.08)
    print(f"P={P}: S={S:.4f} E={S/P:.6f}")
# alternative: only A serial (alpha=0.02)
for P in (512, 2048):
    S = gus(P, 0.02)
    print(f"  (alt, only phase A serial) P={P}: S={S:.4f} E={S/P:.6f}")
# Amdahl-equivalent on the 1-core scaled problem
for P in (512, 2048):
    a = 0.08
    s_unip = a / (a + (1 - a) * P)   # serial fraction of scaled problem measured on 1 core
    print(f"  P={P}: serial fraction on uniprocessor s_uni={s_unip:.6f}; Amdahl check={amd(P, s_unip):.4f}")

print("\n== TASK 10: memory ceilings (32 GiB/node) ==")
GiB = 2**30
for b, label in ((8, "1 double array (8 B/pt)"), (40, "5 doubles/pt (40 B/pt)"), (80, "5 doubles x 2 time levels (80 B/pt)")):
    print(label)
    for nodes in (1, 64, 512):
        M = nodes * 32 * GiB
        pts = M / b
        N = round(pts ** (1 / 3))
        Nn = int(pts ** (1/3))
        print(f"  nodes={nodes:4d} M={nodes*32} GiB  points={pts:.4e}  N_max={Nn}  (per-node n={int((32*GiB/b)**(1/3))})")
print("Weak scaling check: N(P)=N(1)*P^(1/3): N(64)/N(1)=4, N(512)/N(1)=8")

print("\n== TASK 16: GEMM N ~ N1 * P^(1/3), N1=2000 ==")
for P in (1, 8, 64, 512, 4096, 32768):
    N = 2000 * P ** (1 / 3)
    print(f"P={P:6d} N={N:10.1f} flops=2N^3={2*N**3:.3e} per-core flops={2*N**3/P:.3e} mem/core(8B,3 matrices)={3*8*N**2/P/1e6:.2f} MB")

print("\n== TASK 17: stencil surface/volume ==")
n = 128
for P in (1, 8, 64, 512, 4096):
    N = n * round(P ** (1/3))
    # weak: local n fixed
    print(f"weak P={P:5d} global N={N:5d} local n={n} halo/vol per proc = {6*n*n/n**3:.5f}")
Ng = 1024
for P in (1, 8, 64, 512, 4096):
    nloc = Ng / round(P ** (1/3))
    print(f"strong P={P:5d} global N={Ng} local n={nloc:.1f} halo/vol per proc = {6/nloc:.5f}")

print("\n== TASK 18: N-body ==")
# per-iteration time budget T: all-pairs c N^2/P = T  -> N = sqrt(T P / c)
c = 1e-9; T = 1.0
for P in (1, 16, 256, 4096, 65536):
    Nap = math.sqrt(T * P / c)
    # Barnes-Hut: c N ln N / P = T -> solve by iteration
    Nbh = T * P / c / 20
    for _ in range(60):
        Nbh = T * P / c / math.log(Nbh)
    s_ap = 5e-9 * Nap      # serial O(N) work (I/O, tree-free bookkeeping), 5 ns/particle
    s_bh = 5e-9 * Nbh
    print(f"P={P:6d} N_allpairs={Nap:.3e} serial_frac={s_ap/(s_ap+T):.5f} | N_BH={Nbh:.3e} serial_frac={s_bh/(s_bh+T):.5f}")

print("\n== TASK 19: Monte Carlo with tree reduction ==")
T = 10.0            # parallel compute seconds per run (constant, weak scaling)
t_seed = 0.002      # O(1) jump-ahead seeding, serial
t_out = 0.020       # output serialization
t_lvl = 50e-6       # reduction latency per tree level (50 us)
for P in (1, 16, 256, 4096, 65536, 1048576):
    red = t_lvl * math.ceil(math.log2(P)) if P > 1 else 0.0
    ser = t_seed + t_out + red
    a = ser / (ser + T)
    S = gus(P, a)
    print(f"P={P:8d} reduce={red*1e3:7.3f} ms  alpha={a:.6f}  S={S:14.2f}  E={S/P:.6f}")
linear = lambda P: t_lvl * (P - 1)
print("Linear (flat) reduction for contrast:")
for P in (16, 256, 4096, 65536):
    ser = t_seed + t_out + linear(P); a = ser / (ser + T)
    print(f"P={P:8d} reduce={linear(P)*1e3:9.3f} ms alpha={a:.6f} S={gus(P,a):12.2f} E={gus(P,a)/P:.6f}")

print("\n== TASK 12: communication-penalised Gustafson ==")
s, p = 0.04, 0.96
for name, C in (("log2 P", lambda P, k: k * math.log2(P)), ("sqrt P", lambda P, k: k * math.sqrt(P))):
    for k in (0.001,):
        print(name, "kappa=", k)
        for P in (16, 256, 4096, 65536):
            Sc = (s + p * P) / (1 + C(P, k))
            print(f"  P={P:6d} ideal={gus(P,0.04):12.2f} with-comm={Sc:12.2f}  E={Sc/P:.5f}")

print("\n== TASK 15: energy ==")
Pact, Pidle, Tt = 200.0, 60.0, 1.0   # W, W, normalised seconds
for P in (1, 16, 256, 4096):
    s, p = 0.04, 0.96
    EP = Tt * (s * (Pact + (P - 1) * Pidle) + p * P * Pact)
    E1 = Tt * (s + p * P) * Pact
    print(f"P={P:5d} E_P={EP:12.2f} J  E_1core(scaled work)={E1:12.2f} J ratio={EP/E1:.4f}  E_1core_time={Tt*(s+p*P):.2f}s")
