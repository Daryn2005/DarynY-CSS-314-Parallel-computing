# Task 12 — Gustafson with a Communication Overhead Term

## 1. Model

Let the **ideal** scaled run take s + p = 1 (normalised). Add a communication/synchronisation time C(P) ≥ 0 that is incurred on the parallel machine and does not exist on one processor:

T_par(P) = s + p + C(P) = 1 + C(P).

The serial-equivalent time of the same scaled problem is still s + P·p (no communication on one core). Therefore

**S_C(P) = (s + p·P) / (1 + C(P))  = (P − α(P−1)) / (1 + C(P))**   (1)

and **E_C(P) = S_C(P)/P = [1 − α(P−1)/P] / (1 + C(P))**.   (2)

Equivalent "growing α" view: the effective serial fraction is α_eff(P) = (s + C(P))/(1 + C(P)); however (1) is exact and preferable because C is modelled as overhead on the parallel machine, not as serial work.

## 2. Plausible forms of C(P)

| Source | C(P) |
|---|---|
| Tree-based collective (all-reduce, barrier) | κ log₂ P |
| 2-D mesh/torus global exchange, bisection-limited | κ √P |
| 3-D torus all-to-all | κ P^{1/3} |
| Flat/linear gather to rank 0 | κ P |
| Nearest-neighbour halo exchange, constant n per node | κ (independent of P) → absorbed in p |

κ = the per-unit communication cost relative to the (normalised) runtime, e.g. κ = 10⁻³.

## 3. Asymptotics

* C = κ log₂P: S_C ≈ (1−α)P / (κ log₂P) → E_C ≈ (1−α)/(κ log₂ P) → **0** (very slowly). Gustafson's constant-efficiency plateau is lost, but logarithmically.
* C = κ√P: E_C ∼ (1−α)/(κ√P) → 0 faster.
* If C(P) = O(1): E_C → (1−α)/(1+C) — still a constant plateau.

## 4. Numbers (α = 0.04, κ = 0.001 — from calculations/compute_all.py)

| P | ideal S | κ log₂P → S_C (E) | κ√P → S_C (E) |
|---|---|---|---|
| 16 | 15.40 | 15.34 (0.959) | 15.34 (0.959) |
| 256 | 245.80 | 243.85 (0.953) | 241.93 (0.945) |
| 4096 | 3,932.2 | 3,885.6 (0.949) | 3,695.7 (0.902) |
| 65,536 | 62,914.6 | 61,923.8 (0.945) | 50,091.2 (0.764) |

## 5. Restoring fixed time (design implication)

To hold *wall time* fixed, the compute budget must shrink: p′(P) = p − C(P) (assuming 1 = s + p′ + C). Then the amount of parallel work per processor falls and speedup becomes S = s + (1 − s − C(P))P — an *effective* Gustafson with slope (1 − s − C(P)), which declines with P.

## 6. Practical use

Fit κ and the form of C(P) from measured weak-scaling runs (Task 23) by regressing (P − S_meas)/(P−1) against candidate C(P)-terms.
