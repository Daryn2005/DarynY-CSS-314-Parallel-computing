# Task 14 — Isoefficiency of a Gustafson-Compliant Program

## 1. Definitions (Grama, Gupta, Kumar)

* W = problem size = serial time of the best serial algorithm (in time units).
* T_o(W, P) = P·T_P − W = total overhead (all processor-time not spent on useful work).
* E = W/(W + T_o).  Solving for W at constant E:

**W = K · T_o(W, P),  K = E/(1−E).**   (isoefficiency relation)

The isoefficiency function is the Θ-order of W(P) that satisfies this.

## 2. Gustafson's model expressed as overhead

Parallel runtime fixed: T_P = s + p = 1 (normalised). Useful work (serial-equivalent) W = s + pP.

T_o = P·T_P − W = P − (s + pP) = P(1−p) − s = sP − s = **s(P−1)**.

(Sanity: E = W/(W+T_o) = (s+pP)/P·… = (s+pP)/P, i.e. S/P ✓. since W + T_o = P.)

## 3. Isoefficiency function

Set W = K·T_o:

s + pP = K·s(P−1) ⇒ with p = 1−s:  s + (1−s)P = K s (P−1).

For constant s this relation holds with **W = Θ(P)** — in fact with the Gustafson-scaled W = s + (1−s)P, efficiency is

E = W/(W+T_o) = [s+(1−s)P]/P = 1 − s + s/P → 1−s (a constant, Task 04).

**Isoefficiency function of a Gustafson-compliant program: W = Θ(P)** — the best possible (an isoefficiency function cannot be sub-linear in P, since each processor needs at least constant work). The problem must grow only **linearly** with P to hold E = 1−s+s/P ≳ 1−s.

## 4. General statement

If T_o(W,P) = Θ(P) (serial constant time s, nothing else), then W = Θ(P).
If T_o = Θ(P log P) (e.g. tree all-reduce per iteration, per-processor cost log P) ⇒ W = Θ(P log P).
If T_o = Θ(P^{3/2}) (e.g. 2-D bisection) ⇒ W = Θ(P^{3/2}).
Gustafson's law assumes the first and best case; *fixed-time* scaling is only possible when the isoefficiency function is Θ(P).

## 5. Critique

* Gustafson's law hides the assumption in the choice "s is constant". If s itself grows (α(P) increases, Tasks 12, 18), T_o grows faster and the isoefficiency function becomes super-linear: the problem would then have to grow faster than the machine to keep E constant, which violates fixed time.
* Efficiency under fixed-time scaling ≠ constant: E = 1−s+s/P decreases to 1−s. Strict constant-efficiency (isoefficiency) holds for any E ≤ 1−s, with the same Θ(P) growth.
* Isoefficiency is more general: it covers fixed-size (Amdahl: no W growth ⇒ efficiency collapses), fixed-time (this task) and memory-bound regimes by comparing W(P) with the memory limit M(P)=Θ(P); a program is *scalable* iff isoefficiency W(P) ≤ memory-limited problem size.
