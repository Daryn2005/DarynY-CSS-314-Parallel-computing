# Task 15 — Energy Profile under Weak Scaling

## 1. Power model

Each core/node draws **P_act** (total power, watts) while computing and **P_idle** (watts) while waiting (static/leakage power, never zero). Dynamic part: P_dyn = P_act − P_idle. Wall-clock time is fixed at T (normalised T = 1, with s + p = 1).

## 2. Energy on P cores (Gustafson run)

* Serial interval s·T: 1 core active, P−1 idle:  E_ser = sT[P_act + (P−1)P_idle].
* Parallel interval p·T: all P cores active:  E_par = pT·P·P_act.

**E_P = T { s[P_act + (P−1)P_idle] + p·P·P_act }**   (1)

Using s + p = 1:  E_P = T P_act (s + pP) + T s(P−1) P_idle.

The first term is exactly the **useful-work energy** (the energy one core would burn to do the same scaled work, see below); the second is the **idle-waste energy**, proportional to the serial fraction.

## 3. Same work on 1 core

The scaled work needs T₁ = T(s + pP) seconds on one core (Task 02):

**E_1 = T (s + pP) P_act**   (2)

## 4. Comparison

E_P / E_1 = 1 + [ s(P−1) / (s + pP) ] · (P_idle / P_act).   (3)

* As P→∞: s(P−1)/(s+pP) → s/p, so E_P/E_1 → 1 + (α/(1−α))·(P_idle/P_act): a **bounded** overhead, no matter how large P (a consequence of E → 1−α).
* If P_idle = 0 (perfect power-gating): E_P = E_1 — weak scaling costs no extra energy, while time is P/(…) shorter.
* **Energy per unit work** ε = E_P/W = T P_act + T·s(P−1)P_idle/(s+pP): slightly above P_act·T/1 per work unit.

## 5. Numbers (s = 0.04, P_act = 200 W, P_idle = 60 W, T = 1 s) — from `calculations/compute_all.py`

| P | E_P (J) | E_1 (J) (time on 1 core) | E_P/E_1 |
|---|---|---|---|
| 1 | 200 | 200 (1 s) | 1.0000 |
| 16 | 3,116 | 3,080 (15.4 s) | 1.0117 |
| 256 | 49,772 | 49,160 (245.8 s) | 1.0124 |
| 4096 | 796,268 | 786,440 (3,932 s) | 1.0125 |

Limit: 1 + (0.04/0.96)(60/200) = 1.0125 ✓.

## 6. Interpretation

* To finish the scaled job in the same wall-clock time T, a single core is impossible; to **compare** at equal work, the parallel machine pays ≈ 1.25 % more energy but cuts time by S(P) = 3,932× at P = 4096.
* Energy-delay product improves by ~S(P)/1.0125.
* With real systems P_idle ≈ 30–60 % of P_act, so serial phases matter for energy even when α is small. Race-to-idle / DVFS on waiting cores recovers most of the overhead.
* Caveat: includes only compute-node power; network, cooling (PUE) and memory power scale with P and are not included.
