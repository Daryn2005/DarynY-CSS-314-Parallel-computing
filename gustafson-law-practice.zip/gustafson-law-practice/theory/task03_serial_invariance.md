# Task 03 — The Serial-Fraction Invariance Paradox

**Memo.** Frame of reference for measuring overhead.

## 1. The apparent paradox

Amdahl: "if 4% of the work is serial, speedup can never exceed 25."
Gustafson: "with 4% serial, 1024 processors give 983×."
Both quote "4% serial". Both formulas are correct. How?

## 2. The two fractions are different quantities

| Symbol | Measured on | Denominator | Problem size |
|---|---|---|---|
| s (Amdahl) | 1 processor | total 1-processor time of problem W | fixed |
| α (Gustafson) | P processors | total P-processor time of the **scaled** problem | grows with P |

Let σ be the absolute serial time (seconds), which is independent of problem size (start-up, I/O of constants, parameter broadcast), and let π be the parallel work (seconds on one processor) of the *scaled* problem, π = P·p.

* Measured on the parallel machine: α = σ/(σ + π/P).
* Measured on one processor of the same scaled problem: s₁ = σ/(σ + π).

Relation (derived by dividing): 

s₁ = α / (α + (1−α)P)  and  α = s₁P / (1 + s₁(P−1)).

## 3. Numerical demonstration (α = 0.04)

| P | s₁ = α/(α+(1−α)P) | Amdahl using s₁ | Gustafson, α = 0.04 |
|---|---|---|---|
| 16 | 0.002597 | 15.40 | 15.40 |
| 64 | 0.000650 | 61.48 | 61.48 |
| 1024 | 0.0000407 | 983.08 | 983.08 |

(The 3rd column is Amdahl's formula fed with the **uniprocessor** serial fraction of the scaled problem; it reproduces Gustafson exactly, which is the identity shown in Task 02, Step 7.)

## 4. Why the "contradiction" disappears

1. The *uniprocessor* serial fraction of a problem that is P times bigger is P times smaller (roughly), because the serial **time** σ is unchanged while the parallelisable work grew by P. Amdahl's ceiling 1/s₁ therefore rises with P: for P = 1024, 1/s₁ ≈ 24,600 — far above 1024 — so it never binds.
2. Amdahl's pessimism is an artefact of holding the **problem** fixed while processors increase, which forces s to be a constant property of the code. Gustafson holds the **time** fixed and lets the problem absorb the resources.
3. Measuring α on the parallel machine is natural: it is what a profiler on the production run reports ("4% of the run is serial"). Extrapolating that same wall-clock-based number to other P (with the problem scaled) is meaningful *only* if σ really is constant, i.e. only if the serial work does not grow with the problem.

## 5. Caveats — where the invariance fails

* If serial work grows with N (e.g. serial mesh generation O(N), serial I/O of the whole grid, a global gather on one rank), then σ = σ(P) and α is **not** constant; the invariance claim is false (Tasks 12, 13, 18).
* Measuring α on the *serial* machine and plugging it into Gustafson's formula (a common mistake) mixes frames and badly overestimates the loss. Likewise plugging a parallel-measured α into Amdahl's formula gives the wrong, over-pessimistic answer (see Task 05 for the nCUBE example).
