# Task 11 — Gustafson vs. the Sun–Ni Memory-Bounded Speedup Model

## 1. The general model

Let s = serial fraction of the *base* (one-processor) problem, and let G(P) be the factor by which the parallel workload grows when P processors (with P× the memory) are available:

**S\*(P) = [ s + (1−s)·G(P) ] / [ s + (1−s)·G(P)/P ]**

| G(P) | Meaning | Reduces to |
|---|---|---|
| 1 | fixed size | Amdahl: 1/(s+(1−s)/P) |
| P | workload ∝ processors (fixed *time* if parallel work scales perfectly) | Gustafson: s + (1−s)P (check: numerator = s+(1−s)P, denominator = s+(1−s) = 1) |
| g(P) where g(m·M)=… | workload fills the available memory | Sun–Ni |

In Sun–Ni, G(P) is determined by the *memory-to-work relation*: if memory scales as P·M and work W as a function of memory, W = f(M), then G(P) = f(P·M)/f(M).

## 2. Example G(P) laws

| Algorithm | Memory M | Work W | G(P) when memory grows ∝ P |
|---|---|---|---|
| Vector/Monte-Carlo, O(N) | N | N | P (Gustafson exactly) |
| Dense matmul, N×N | N² | N³ = M^{3/2} | P^{3/2} |
| 3-D explicit stencil, per step | N³ | N³ | P (per step) — but time-steps ∝ N so total work ∝ P^{4/3} |
| Dense LU | N² | N³ | P^{3/2} |
| N-body direct | N | N² | P² |

## 3. Comparing the predictions

For G(P) = P^{3/2}, s = 0.05, P = 64:

* Gustafson: 0.05 + 0.95·64 = 60.85.
* Sun–Ni: numerator = 0.05 + 0.95·512 = 486.45; denominator = 0.05 + 0.95·512/64 = 7.65; S\* = **63.6**.

Wall time is **not** constant under Sun–Ni: the parallel time grows by G(P)/P = 8× relative to the base run.

## 4. When does Gustafson under- or over-estimate?

**Underestimates** the achievable *throughput/speedup* when G(P) > P: the memory can hold a problem whose work grows super-linearly; as long as the user tolerates longer run times, the machine does more useful work per unit time per processor (S\* → P as G(P)/P → ∞ because the serial part becomes negligible). Gustafson’s fixed-time constraint is too strict in that regime.

**Overestimates** when G(P) < P:
* The physical problem or data set cannot be enlarged by P (e.g. fixed-size input, a finite molecule, a fixed mesh from CAD) — a user with G ≈ 1 is in Amdahl’s world.
* Memory per node is replicated (O(N) per node regardless of P, e.g. replicated lookup tables), so only part of the memory is usable: G(P) < P.
* The serial/communication components grow with P, i.e. α is not constant (Task 12).
* Time-complexity grows superlinearly with N while the time budget is fixed (Task 13): e.g. if W = N^{3/2}-style costs prevent the problem from scaling by P under fixed time.

## 5. Take-away

Gustafson = Sun–Ni with G(P) = P (**fixed time**); Amdahl = G = 1 (**fixed size**); Sun–Ni with G chosen by memory is **memory-bounded** speedup. Which law applies depends on which resource (time, memory, user need) actually constrains the user’s problem growth.
