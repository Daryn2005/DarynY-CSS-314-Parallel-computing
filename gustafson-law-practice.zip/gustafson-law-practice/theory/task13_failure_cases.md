# Task 13 — When Gustafson's Weak-Scaling Assumption Fails

Gustafson requires: (i) work can be grown by exactly P×, (ii) the grown work is perfectly parallel, (iii) the runtime of the grown problem on P processors equals the baseline runtime, (iv) the serial time is independent of the problem size. Two concrete algorithm families break (iii) and (iv).

## Case A — Implicit PDE solve with Conjugate Gradients (and explicit time-stepping with a CFL limit)

**Setup.** 3-D Poisson/diffusion problem on an N³ grid, weak scaling: constant n³ points per process, so N = n·P^{1/3}.

**Why the constant-time premise breaks.**
* Condition number of the discrete Laplacian κ ∝ N², CG iterations ∝ √κ ∝ N = n·P^{1/3}.
* Each iteration costs O(n³) flops + a halo exchange + **two global dot products** (all-reduce, ∝ log P latency).
* Time per solve: T(P) ∝ P^{1/3}·(t_flop n³ + t_halo + t_allreduce log P).

| P | N/n | CG iterations (rel.) | Run time (rel. to P = 1) |
|---|---|---|---|
| 1 | 1 | 1 | 1 |
| 64 | 4 | 4 | ≥ 4 |
| 4096 | 16 | 16 | ≥ 16 |

Weak-scaling efficiency ≤ P^{−1/3}: at P = 4096 it is ≤ 6.25 % even with zero communication cost. The same law applies to explicit time stepping: the CFL condition Δt ∝ Δx = L/N forces #steps ∝ N, total work ∝ N⁴ = P^{4/3}·const.

**Remedy.** Algorithmically scalable solvers (multigrid: O(1) iterations, O(N) work) restore constant iteration counts; communication (coarse levels) then dominates. Alternatively choose a *time-step–scaled* (fixed number of steps) benchmark, which is a different experiment from Gustafson's.

## Case B — Distributed FFT / global sort (all-to-all communication)

**Setup.** 3-D FFT (or sample sort) of a data set with n elements per process, total N = nP.

**Why it breaks.**
* A global transpose/all-to-all moves Θ(N) data across the machine; per-process volume n is constant, but the data crosses the **network bisection**. For a 3-D torus the bisection bandwidth grows only as P^{2/3} while the crossing traffic grows ∝ P, so communication time ∝ P^{1/3}.
* The computation is O(N log N) overall → O(n log N) per process: the per-process work grows as log P (the work does *not* scale as exactly P×).
* Sample sort adds O(P) splitter-selection serial work on one process (∝ P serial time) → α(P) not constant.

| P | log-factor (log₂N/log₂n, n = 2²⁰) | bisection-limited comm. (rel.) |
|---|---|---|
| 1 | 1.00 | 1 |
| 4096 | 1.60 | 16 |

Hence runtime is not constant; the "fixed-time" scaled speedup is replaced by an isoefficiency curve with N growing faster than P (e.g. Θ(P^{4/3}) data for torus-limited FFT).

## Summary

| | Premise broken | Root cause | Observed scaling |
|---|---|---|---|
| A | constant runtime | iteration count/time steps grow with N | T ∝ P^{1/3} |
| B | constant per-process time; α constant | all-to-all traffic, N log N complexity, O(P) serial splitter work | T ∝ P^{1/3} (torus), + log P factor |
