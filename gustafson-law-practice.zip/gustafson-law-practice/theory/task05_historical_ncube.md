# Task 05 — The nCUBE 10 Experiment and the "Amdahl's Pessimism" Fallacy

> **Source note.** The experimental figures below (three applications, speedups ≈ 1009, 1020, 1016 on 1,024 processors) are quoted from memory of Gustafson, Montry & Benner (Sandia National Laboratories, 1988) and Gustafson, "Reevaluating Amdahl's Law", *CACM* 31(5), 1988. Please verify the exact numbers against the papers before citing them. The 0.4 % figure is the one given in your task sheet.

## 1. Historical scenario

* **Machine:** a 1,024-processor nCUBE/10 hypercube at Sandia. Each node had its own memory (≈ 0.5 MB), so a single node could only hold a very small problem.
* **Applications:** three real engineering codes — beam-stress analysis (finite elements), baffled-surface wave simulation (finite differences), and unstable fluid-flow modelling (flux-corrected transport).
* **Belief at the time:** Amdahl-style arguments suggested that speedups of several hundred were implausible for realistic serial fractions of a few percent (1/s ≤ 250 for s = 0.4 %).
* **Result:** measured *scaled* speedups of roughly 1,000× (≈ 98–99.6 % of the ideal 1,024).

## 2. Why Amdahl's ceiling appeared to be violated

Measured serial fraction on the parallel machine: α = s′ = 0.004 (0.4 %).

| Interpretation | Formula | Result at P = 1024 |
|---|---|---|
| Naïve Amdahl with s = 0.004 | 1/(0.004 + 0.996/1024) | **201.1** |
| Gustafson with α = 0.004 | 1024 − 0.004·1023 | **1019.9** |
| Uniprocessor-equivalent s₁ of the scaled problem | 0.004/(0.004+0.996·1024) | 3.9×10⁻⁶ |

Amdahl with s = 0.004 predicts ≈ 201 — five times lower than the observed ≈ 1,000. Yet the Amdahl "ceiling" 1/s = 250 was exceeded by a factor ≈ 4.

## 3. How problem expansion dismantled the ceiling

1. **Memory-per-node constraint.** Each node's memory was small; to use the full machine the problem was made 1,024× larger (finer meshes, more elements), keeping per-node work, and hence the run time, roughly constant.
2. **The serial part does not grow with the problem.** Program load, parameter input, mesh topology set-up and the final output are fixed costs; the parallel work grew with N. The serial fraction of the *scaled* run (uniprocessor view) is therefore s₁ ≈ 4×10⁻⁶, not 4×10⁻³. Amdahl with *that* s₁ gives back 1,020 (Task 02, Step 7).
3. **Serial fraction is a property of (problem, machine) pair,** not of the code.
4. The experiment therefore showed that Amdahl's law is a statement about *fixed-size* speedup and does not bound *scaled* speedup. It did not violate Amdahl; it violated the assumption that the problem size must be fixed.

## 4. Limits of the result

* The scaled-speedup was *estimated*, not measured against a real 1-node run of the full problem (that would not fit in one node's memory); the single-node time was extrapolated from the measured serial and parallel fractions — the same assumption Gustafson's formula makes (no extra parallel overhead).
* Communication was nearest-neighbour on a hypercube with constant surface/volume per node (Task 17); that is why the workloads scaled so well. Not all problems do (Task 13, 20).
