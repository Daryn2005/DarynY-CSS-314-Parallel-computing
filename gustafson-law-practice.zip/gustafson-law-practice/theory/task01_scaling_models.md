# Task 01 — Strong vs. Weak Scaling: Amdahl (1967) and Gustafson (1988)

## 1. Two questions, not one

| | Amdahl (1967) | Gustafson–Barsis (1988) |
|---|---|---|
| Question asked | "How much faster can I solve **this** problem?" | "How much **bigger** a problem can I solve in the **same time**?" |
| Quantity held fixed | Problem size W (total work) | Wall-clock time T on the parallel machine |
| Quantity that varies | Time T(P) shrinks | Work W(P) grows |
| Scaling type | **Strong scaling** | **Weak scaling** |
| Serial fraction measured on | A single processor (s) | The P-processor run (α, sometimes written s′) |
| Formula | S_A(P) = 1 / (s + (1−s)/P) | S_G(P) = P − α(P−1) = α + (1−α)P |
| Limit as P→∞ | 1/s (finite ceiling) | ∞ (grows linearly, slope 1−α) |
| Efficiency limit | E → 0 (like 1/(sP)) | E → 1−α (constant) |

## 2. Behaviour of problem size as P → ∞

* **Amdahl:** the problem dimension N (and work W = W(N)) is a constant independent of P. Each processor receives a share W/P that shrinks to zero, so the parallelisable time (1−s)/P vanishes and only the serial time s remains: T(∞) = s·T(1), hence the ceiling 1/s.
* **Gustafson:** the problem grows with the machine. Work on the parallel part is W_par(P) = p·P (in units where the parallel run takes s+p = 1). Each processor always holds a constant amount of parallel work; the parallel time stays p, and the serial time s stays constant, because s is an *absolute* time that does not depend on the problem size growth (e.g. start-up, I/O of fixed-size parameter files). N therefore grows without bound, e.g. N ∝ P (1-D workloads), N ∝ P^{1/3} for 3-D grids with constant volume per node, N ∝ P^{1/3} for GEMM (see Task 16).

## 3. Why "fixed-size" vs "fixed-time"

* Amdahl's Law is *fixed-size* because the numerator of the speedup, T(1) = s + (1−s) (normalised), is the time of the same problem in every term of the comparison. Only the denominator changes with P.
* Gustafson's Law is *fixed-time* because the **parallel runtime is the invariant**: s + p = 1 for every P. What the machine gets bigger for is the amount of work finished in that one unit of time; speedup is defined as (work done on P) / (work done on 1) in that time, equivalently the time a single processor would need for the *scaled* problem divided by the (fixed) parallel time.

## 4. Philosophical and physical divergence

1. **What is a "fixed" thing in real life?** Amdahl pictures a user with one particular job (a payroll run, one image). Gustafson pictures a scientist with a time budget (an overnight weather forecast, a 10-hour design-optimisation slot) who buys a bigger machine to raise **resolution, fidelity or model complexity**. In practice, scientific users do the latter: nobody runs a 100-point grid on a million cores.
2. **Where the serial fraction lives.** Amdahl treats s as an intrinsic fraction of the *algorithm* ("10% of my code is sequential"). Gustafson observes that the serial part is mostly *fixed-cost overhead* (set-up, I/O of constants, program load) which does **not** grow with the problem, so the serial *fraction* of the scaled problem shrinks as 1/P (Task 03).
3. **Optimism vs pessimism.** Amdahl’s result seemed to say massive parallelism is pointless beyond 1/s; Gustafson’s says that it is limited only by how fast the serial time can be kept constant relative to the parallel time. Both are mathematically correct; they answer different questions. Neither accounts for communication growth, memory limits or load imbalance (Tasks 11–13).
4. **Both are special cases of one model.** Sun–Ni’s memory-bounded speedup with G(P)=1 gives Amdahl, with G(P)=P gives Gustafson (Task 11).

## 5. Worked contrast (s = α = 0.05, P = 1024)

* Amdahl: 1/(0.05 + 0.95/1024) = **19.6** (ceiling 20).
* Gustafson: 1024 − 0.05·1023 = **972.9**.

The same number 0.05 means "5% of the one-processor time of a fixed problem" in the first case and "5% of the P-processor time of a grown problem" in the second — that difference of reference frame, not a contradiction of mathematics, produces a 50× gap.
