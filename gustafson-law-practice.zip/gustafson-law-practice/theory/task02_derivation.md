# Task 02 — Derivation of Gustafson's Scaled Speedup

## Setup and notation

* P = number of identical processors.
* The scaled problem is run on P processors; its wall-clock time is **normalised** to 1:

  T_par(P) = s + p = 1  (line 1)

  where s = time spent in serial sections (one processor busy, others idle), p = time spent in the parallel sections (all P processors busy).
* α ≡ s/(s+p) = s is the serial fraction **measured on the parallel machine** (because s+p=1, α = s numerically).

## Step 1 — work done by the parallel run

During the serial interval s only one processor does useful work: work = s·r, where r is the speed of a single processor (r = 1 work unit per time unit).
During the parallel interval p all P processors work in parallel: work = P·p·r.

Total work of the scaled problem: W(P) = s + P·p.  (line 2)

## Step 2 — time for one processor to do that same work

Assuming the algorithm does not do extra work when serialised (no parallel overhead is hidden in p, the best-case assumption) and that one processor executes at the same speed r = 1:

T_serial_equiv(P) = W(P)/r = s + P·p.  (line 3)

(The serial part costs s on one processor, and the work that took p on P processors costs P·p on one.)

## Step 3 — speedup = serial-equivalent time / parallel time

S(P) = T_serial_equiv(P) / T_par(P) = (s + P·p)/(s + p) = s + P·p.  (line 4, using s+p=1)

## Step 4 — eliminate p

From line 1: p = 1 − s = 1 − α, so

S(P) = α + P(1−α) = α + P − αP = **P − α(P − 1)**.  (line 5) ∎

## Step 5 — sanity checks

| Case | Result | Meaning |
|---|---|---|
| α = 0 | S = P | perfectly parallel; ideal linear |
| α = 1 | S = P − (P−1) = 1 | entirely serial; no benefit |
| P = 1 | S = 1 | trivial |
| dS/dP = 1 − α | slope of a straight line | every added processor contributes (1−α) of a processor |

## Step 6 — efficiency

E(P) = S(P)/P = 1 − α(P−1)/P = 1 − α + α/P. (line 6)

## Step 7 — equivalence with Amdahl (the "bridge" identity)

Define the serial fraction of the scaled problem **as measured on one processor**:

s_1 = s/(s + P·p) = α/(α + (1−α)P).

Substituting into Amdahl's S_A = 1/(s_1 + (1−s_1)/P):

s_1 + (1−s_1)/P = [α + (1−α)]/(α + (1−α)P) = 1/(α + (1−α)P)

⇒ S_A = α + (1−α)P = S_G. ∎

So Gustafson's formula is Amdahl's law applied to the *scaled* problem with its own uniprocessor serial fraction s_1, which shrinks like 1/P (Task 03).
