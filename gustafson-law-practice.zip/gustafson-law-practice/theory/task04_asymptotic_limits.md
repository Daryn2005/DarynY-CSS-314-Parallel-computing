# Task 04 — Asymptotic Parallel Efficiency

## 1. Gustafson

E_G(P) = S(P)/P = (P − α(P−1))/P = 1 − α + α/P.

**Limit.** For fixed α ∈ [0,1]:

lim_{P→∞} E_G(P) = (1 − α) + lim α/P = **1 − α**.

*Proof.* α/P → 0 as P→∞ since α is a constant. ∎

Monotonicity: dE_G/dP = −α/P² < 0 for α>0, so E_G decreases monotonically from E(1)=1, but is bounded below by 1−α — it never decays to zero. The total loss 1 − E_G = α(P−1)/P < α for every P.

## 2. Amdahl

S_A(P) = 1/(s + (1−s)/P) ⇒ E_A(P) = 1/(sP + 1 − s).

**Limit.** lim_{P→∞} E_A(P) = lim 1/(sP + 1 − s) = **0** for s > 0 (and 1 for s = 0).

Asymptotically E_A ≈ 1/(sP): efficiency is inversely proportional to P.
*Proof.* denominator sP + (1−s) → ∞. ∎

## 3. Comparison (α = s = 0.04)

| P | E_Gustafson = 1 − α + α/P | E_Amdahl = 1/(0.04P + 0.96) |
|---|---|---|
| 16 | 0.9625 | 0.6250 |
| 64 | 0.9606 | 0.2841 |
| 1024 | 0.9600 | 0.02386 |
| 16384 | 0.9600 | 0.00152 |

## 4. Deductions

* Under Gustafson, a constant fraction **1−α** of the machine is always productively used; processors are "worth" 1−α each at any scale. This is why petascale machines are economically viable for scalable workloads.
* Under Amdahl efficiency collapses, so large machines are usable only if the speedup you want is below ≈ 1/s.
* The difference lives in the definition of the problem: fixed size makes the per-processor work vanish while the serial time stays; scaled size keeps per-processor work constant.
