#!/usr/bin/env python3
"""Task 23 - mean/std per configuration and least-squares fit of alpha_observed.

Scaled speedup per run (Gustafson's own definition):
    S_run(P) = ( s1 + P * w1 ) / T_wall(P)
where
    s1 = mean serial-phase time at P=1,
    w1 = mean per-worker compute time at P=1,
    T_wall(P) = measured wall clock (includes pool start-up and reduction).
Numerator = time the SCALED problem would need on one processor.

Model:  S = P - alpha (P-1)   =>   P - S = alpha (P-1)
Least squares through the origin in (P-1, P-S):
    alpha_hat = sum (P-1)(P-S) / sum (P-1)^2
    SE(alpha_hat) = sqrt( RSS/(n-1) / sum (P-1)^2 )

Fits are reported for (a) all configurations and (b) only P <= hardware threads.
"""
import csv
import json
import math
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load(path):
    with open(path) as fh:
        return list(csv.DictReader(fh))


def fit(points):
    """points: list of (P, S). Returns alpha, se, n."""
    pts = [(P, S) for P, S in points if P > 1]
    if not pts:
        return float("nan"), float("nan"), 0
    sxx = sum((P - 1) ** 2 for P, _ in pts)
    a = sum((P - 1) * (P - S) for P, S in pts) / sxx
    rss = sum((P - S - a * (P - 1)) ** 2 for P, S in pts)
    se = math.sqrt(rss / max(1, len(pts) - 1) / sxx) if len(pts) > 1 else float("nan")
    return a, se, len(pts)


def main(path=None):
    path = path or os.path.join(HERE, "results.csv")
    rows = load(path)
    base = [r for r in rows if int(r["P"]) == 1]
    s1 = st.mean(float(r["serial_s"]) for r in base)
    w1 = st.mean(float(r["mean_worker_compute_s"]) for r in base)
    hw = int(rows[0]["hw_concurrency"])

    by_p = {}
    for r in rows:
        P = int(r["P"])
        S = (s1 + P * w1) / float(r["wall_s"])
        by_p.setdefault(P, []).append((float(r["wall_s"]), S))

    summary = []
    for P in sorted(by_p):
        walls = [w for w, _ in by_p[P]]
        Ss = [s for _, s in by_p[P]]
        summary.append({
            "P": P, "n_runs": len(walls),
            "wall_mean_s": st.mean(walls), "wall_std_s": st.stdev(walls) if len(walls) > 1 else 0.0,
            "S_mean": st.mean(Ss), "S_std": st.stdev(Ss) if len(Ss) > 1 else 0.0,
            "S_stderr": (st.stdev(Ss) / math.sqrt(len(Ss))) if len(Ss) > 1 else 0.0,
            "weak_efficiency_T1_over_TP": st.mean(by_p[1][i][0] for i in range(len(by_p[1]))) / st.mean(walls),
            "oversubscribed": int(P > hw),
        })
    all_pts = [(P, st.mean(s for _, s in by_p[P])) for P in by_p]
    hw_pts = [(P, S) for P, S in all_pts if P <= hw]
    a_all, se_all, n_all = fit(all_pts)
    a_hw, se_hw, n_hw = fit(hw_pts)
    out = {"hw_concurrency": hw, "s1_serial_phase_s": s1, "w1_worker_compute_s": w1,
           "alpha_baseline_P1": s1 / (s1 + w1),
           "fit_all_configurations": {"alpha": a_all, "stderr": se_all, "n_points": n_all},
           "fit_P_le_hw": {"alpha": a_hw, "stderr": se_hw, "n_points": n_hw},
           "summary": summary}
    with open(os.path.join(HERE, "fit_results.json"), "w") as fh:
        json.dump(out, fh, indent=2)

    print(f"hardware threads = {hw}; s1 = {s1:.4f}s; w1 = {w1:.4f}s; alpha(P=1 baseline) = {s1/(s1+w1):.4f}")
    print(f"{'P':>4} {'runs':>4} {'wall mean':>10} {'wall std':>9} {'S mean':>8} {'S std':>7} {'E=T1/TP':>8}  note")
    for r in summary:
        print(f"{r['P']:4d} {r['n_runs']:4d} {r['wall_mean_s']:10.4f} {r['wall_std_s']:9.4f} {r['S_mean']:8.3f} "
              f"{r['S_std']:7.3f} {r['weak_efficiency_T1_over_TP']:8.3f}  {'oversubscribed' if r['oversubscribed'] else ''}")
    print(f"alpha_observed (all P>1 points)   = {a_all:.4f} +/- {se_all:.4f}  (n={n_all})")
    print(f"alpha_observed (P>1, P<=hw only)  = {a_hw:.4f} +/- {se_hw:.4f}  (n={n_hw})")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
