#!/usr/bin/env python3
"""Task 21 - Parametric Amdahl vs Gustafson simulator.

Models strong scaling (Amdahl) and weak scaling (Gustafson) for
    1 <= P <= 65,536   and   0.001 <= alpha <= 0.20
and writes (a) a structured CSV and (b) overlay plots.

Usage
-----
    python3 benchmarks/simulator.py                       # defaults
    python3 benchmarks/simulator.py --alphas 0.01 0.05 0.1 --pmax 4096 \
            --csv benchmarks/sim_output.csv --plot plots/simulator_overlay.png
"""
import argparse
import csv
import math
import os

P_MIN, P_MAX = 1, 65536
A_MIN, A_MAX = 0.001, 0.20


def amdahl(P, s):
    """Fixed-size speedup, s = serial fraction measured on ONE processor."""
    return 1.0 / (s + (1.0 - s) / P)


def gustafson(P, a):
    """Fixed-time (scaled) speedup, a = serial fraction measured on P processors."""
    return P - a * (P - 1)


def core_counts(pmax):
    """Powers of two from 1 up to pmax (inclusive)."""
    out, p = [], 1
    while p <= pmax:
        out.append(p)
        p *= 2
    return out


def simulate(alphas, pmax):
    rows = []
    for a in alphas:
        for P in core_counts(pmax):
            sa, sg = amdahl(P, a), gustafson(P, a)
            rows.append({
                "P": P,
                "alpha": a,
                "amdahl_speedup": sa,
                "amdahl_efficiency": sa / P,
                "gustafson_speedup": sg,
                "gustafson_efficiency": sg / P,
                "ratio_gustafson_over_amdahl": sg / sa,
                "amdahl_ceiling": 1.0 / a,
            })
    return rows


def write_csv(rows, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow({k: (f"{v:.10g}" if isinstance(v, float) else v) for k, v in r.items()})


def plot(rows, alphas, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2))
    cmap = plt.get_cmap("viridis")
    for ax, logy in zip(axes, (True, False)):
        Ps = sorted({r["P"] for r in rows})
        ax.plot(Ps, Ps, "k:", lw=1.2, label="ideal  S = P")
        for i, a in enumerate(alphas):
            c = cmap(i / max(1, len(alphas) - 1) * 0.85)
            sub = [r for r in rows if r["alpha"] == a]
            ax.plot([r["P"] for r in sub], [r["gustafson_speedup"] for r in sub],
                    "-", color=c, lw=2, label=f"Gustafson  α={a:g}")
            ax.plot([r["P"] for r in sub], [r["amdahl_speedup"] for r in sub],
                    "--", color=c, lw=2, label=f"Amdahl  s={a:g}")
        ax.set_xscale("log", base=2)
        if logy:
            ax.set_yscale("log", base=2)
            ax.set_title("log-log view")
        else:
            ax.set_ylim(0, 128)
            ax.set_xlim(1, 128)
            ax.set_title("zoom: P <= 128 (linear y)")
        ax.set_xlabel("processors P")
        ax.set_ylabel("speedup S(P)")
        ax.grid(True, which="both", alpha=0.3)
    axes[0].legend(fontsize=7, ncol=2, loc="upper left")
    fig.suptitle("Strong scaling (Amdahl, dashed) vs weak scaling (Gustafson, solid)")
    fig.tight_layout()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fig.savefig(path, dpi=200)
    fig.savefig(os.path.splitext(path)[0] + ".pdf")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--alphas", type=float, nargs="+", default=[0.001, 0.01, 0.04, 0.08, 0.20])
    ap.add_argument("--pmax", type=int, default=P_MAX)
    ap.add_argument("--csv", default="benchmarks/sim_output.csv")
    ap.add_argument("--plot", default="plots/simulator_overlay.png")
    a = ap.parse_args()
    for x in a.alphas:
        if not (A_MIN <= x <= A_MAX):
            ap.error(f"alpha {x} outside [{A_MIN}, {A_MAX}]")
    if not (P_MIN <= a.pmax <= P_MAX):
        ap.error(f"pmax must be in [{P_MIN}, {P_MAX}]")
    rows = simulate(a.alphas, a.pmax)
    write_csv(rows, a.csv)
    plot(rows, a.alphas, a.plot)
    print(f"wrote {len(rows)} rows -> {a.csv}; plots -> {a.plot} (+ .pdf)")


if __name__ == "__main__":
    main()
