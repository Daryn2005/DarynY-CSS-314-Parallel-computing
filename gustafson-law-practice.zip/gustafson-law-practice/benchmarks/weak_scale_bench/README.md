# Weak-scaling benchmark (Task 22)

Python 3.9+ with NumPy. No compilation needed.

```bash
pip install numpy matplotlib
cd benchmarks/weak_scale_bench
python3 weak_bench.py                       # auto thread counts (>=5), 5 runs each -> ../results.csv
python3 weak_bench.py --threads 1 2 4 8 16 --runs 5 --k 200000000
cd ../.. && python3 benchmarks/fit_gustafson.py && python3 plots/make_plots.py
```

* Per-worker problem size `k` is constant, so total work grows as `k·P` (weak scaling).
* A fixed serial phase (parent) and the process start-up/reduction cost are included in wall time.
* `--threads` defaults to powers of two up to the hardware concurrency, padded with
  oversubscribed counts (flagged `oversubscribed=1`) until at least 5 distinct counts exist.
* Re-run on your own multi-core machine before submitting: the committed `results.csv`
  was produced on a 2-vCPU cloud VM, so only P = 1, 2 are real scaling points.
