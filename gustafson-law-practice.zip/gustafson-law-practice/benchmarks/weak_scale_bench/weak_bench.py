#!/usr/bin/env python3
"""Task 22 - Empirical weak-scaling benchmark (Python multiprocessing + NumPy).

Workload
--------
Numerical integration  pi = integral_0^1 4/(1+x^2) dx  by the midpoint rule.

  * Parallel part : every worker integrates K points (K constant per worker),
                    so total work = K * P  (weak scaling).
  * Serial part   : a FIXED amount of work done by the parent process
                    (setup/"I/O" stand-in + final reduction); it does NOT grow
                    with P.  Its duration is the s in  S(P) = s + p*P.
  * Process start-up/teardown is INCLUDED in wall-clock time (it is real overhead).

Usage
-----
    python3 weak_bench.py                          # auto thread counts, 5 runs each
    python3 weak_bench.py --threads 1 2 4 8 --runs 5 --k 20000000 --out ../results.csv

Output: CSV with one row per (P, run).
"""
import argparse
import csv
import multiprocessing as mp
import os
import time

import numpy as np

CHUNK = 1_000_000


def integrate(args):
    """Worker: midpoint rule on [lo, hi) with k points. Returns (partial_sum, compute_seconds)."""
    lo, hi, k = args
    t0 = time.perf_counter()
    h = (hi - lo) / k
    total = 0.0
    done = 0
    while done < k:
        m = min(CHUNK, k - done)
        x = lo + (done + np.arange(m) + 0.5) * h
        total += float(np.sum(4.0 / (1.0 + x * x))) * h
        done += m
    return total, time.perf_counter() - t0


def serial_phase(n_serial):
    """Fixed serial work (same for every P): parent-side setup + I/O stand-in."""
    t0 = time.perf_counter()
    rng = np.random.default_rng(12345)
    a = rng.random(n_serial)
    acc = 0.0
    for _ in range(10):                       # keep the cost independent of P
        acc += float(np.sum(np.sqrt(a) * np.sin(a)))
    return acc, time.perf_counter() - t0


def one_run(P, k, n_serial):
    ctx = mp.get_context("fork")
    t_wall0 = time.perf_counter()
    _, t_serial = serial_phase(n_serial)
    t_par0 = time.perf_counter()
    with ctx.Pool(P) as pool:
        tasks = [(i / P, (i + 1) / P, k) for i in range(P)]
        res = pool.map(integrate, tasks, chunksize=1)
    t_par = time.perf_counter() - t_par0
    pi_est = sum(r[0] for r in res)           # reduction (serial, O(P))
    t_wall = time.perf_counter() - t_wall0
    worker_compute = sum(r[1] for r in res) / len(res)
    return {"wall_s": t_wall, "serial_s": t_serial, "parallel_phase_s": t_par,
            "mean_worker_compute_s": worker_compute, "pi_error": abs(pi_est - np.pi)}


def default_threads(hw):
    base = [p for p in (1, 2, 4, 8, 16, 32, 64, 128) if p <= hw]
    if hw not in base:
        base.append(hw)
    extra = hw + 1
    cand = [extra, 2 * hw, 4 * hw]
    for c in cand:
        if len(set(base)) >= 5:
            break
        base.append(c)
    return sorted(set(base))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", type=int, nargs="+")
    ap.add_argument("--runs", type=int, default=5)
    ap.add_argument("--k", type=int, default=200_000_000, help="points per worker (constant)")
    ap.add_argument("--n-serial", type=int, default=500_000, help="size of the fixed serial phase")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "results.csv"))
    a = ap.parse_args()

    hw = os.cpu_count() or 1
    threads = a.threads or default_threads(hw)
    print(f"hardware concurrency = {hw}; thread counts = {threads}; runs = {a.runs}; k = {a.k}")
    one_run(1, 200_000, 100_000)              # warm-up (imports, page faults)

    rows = []
    for P in threads:
        for r in range(1, a.runs + 1):
            m = one_run(P, a.k, a.n_serial)
            m.update({"P": P, "run": r, "hw_concurrency": hw, "oversubscribed": int(P > hw), "k_per_worker": a.k})
            rows.append(m)
            print(f"P={P:3d} run={r} wall={m['wall_s']:.3f}s serial={m['serial_s']:.3f}s "
                  f"worker={m['mean_worker_compute_s']:.3f}s")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["P", "run", "hw_concurrency", "oversubscribed", "k_per_worker",
                                           "wall_s", "serial_s", "parallel_phase_s",
                                           "mean_worker_compute_s", "pi_error"])
        w.writeheader()
        for m in rows:
            w.writerow({k: (f"{v:.9g}" if isinstance(v, float) else v) for k, v in m.items() if k in w.fieldnames})
    print("wrote", os.path.abspath(a.out))


if __name__ == "__main__":
    main()
