#!/usr/bin/env python3
"""Task 24 - publication plots: ideal vs Gustafson fit vs measured (+/- SE) vs Amdahl.
Run from the repo root:  python3 plots/make_plots.py
Reads benchmarks/fit_results.json, writes plots/scaling_comparison.{png,pdf}.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fit = json.load(open(os.path.join(ROOT, "benchmarks", "fit_results.json")))
hw = fit["hw_concurrency"]
rows = fit["summary"]
a_hw = fit["fit_P_le_hw"]["alpha"]
a_all = fit["fit_all_configurations"]["alpha"]
a_base = fit["alpha_baseline_P1"]

Pmax = max(r["P"] for r in rows)
xs = [1 + i * (Pmax - 1) / 200 for i in range(201)]
gus = lambda P, a: P - a * (P - 1)
amd = lambda P, s: 1.0 / (s + (1 - s) / P)

fig, ax = plt.subplots(figsize=(7.4, 5.0))
ax.axvspan(hw, Pmax * 1.05, color="0.92", zorder=0, label=f"oversubscribed (P > {hw} hardware threads)")
ax.plot(xs, xs, "k:", lw=1.4, label="(1) ideal linear  S = P")
ax.plot(xs, [gus(x, a_hw) for x in xs], "-", color="#1b6ca8", lw=2,
        label=f"(2) Gustafson, fit on P ≤ {hw}:  α = {a_hw:.4f}")
ax.plot(xs, [gus(x, a_base) for x in xs], "-", color="#2a9d8f", lw=1.6,
        label=f"    Gustafson, baseline α(P=1) = {a_base:.4f}")
ax.plot(xs, [gus(x, a_all) if gus(x, a_all) > 0 else float('nan') for x in xs], "-.", color="0.5", lw=1.2,
        label=f"    Gustafson, fit on all points:  α = {a_all:.3f}")
ax.errorbar([r["P"] for r in rows], [r["S_mean"] for r in rows], yerr=[r["S_stderr"] for r in rows],
            fmt="o", color="#d1495b", capsize=4, ms=6, label="(3) measured (mean ± std. error, 5 runs)")
ax.plot(xs, [amd(x, a_base) for x in xs], "--", color="#e09f3e", lw=2,
        label=f"(4) Amdahl, s = {a_base:.4f}  (same serial fraction)")
ax.set_xlabel("worker processes P (work per worker constant)")
ax.set_ylabel("scaled speedup S(P)")
ax.set_xlim(0.8, Pmax * 1.05)
ax.set_ylim(0, Pmax * 1.05)
ax.set_title(f"Weak scaling on a {hw}-vCPU VM: measured vs theory")
ax.grid(alpha=0.3)
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
out = os.path.join(ROOT, "plots", "scaling_comparison")
fig.savefig(out + ".png", dpi=220)
fig.savefig(out + ".pdf")
print("wrote", out + ".png/.pdf")

# Companion: weak-scaling efficiency
fig, ax = plt.subplots(figsize=(6, 3.8))
ax.plot([r["P"] for r in rows], [r["weak_efficiency_T1_over_TP"] for r in rows], "o-", color="#d1495b")
ax.axvline(hw, color="k", ls=":", lw=1)
ax.set_xlabel("P"); ax.set_ylabel("weak efficiency  T(1)/T(P)"); ax.set_ylim(0, 1.15); ax.grid(alpha=0.3)
ax.set_title("Weak-scaling efficiency (dotted line = hardware threads)")
fig.tight_layout()
fig.savefig(os.path.join(ROOT, "plots", "weak_efficiency.png"), dpi=200)
