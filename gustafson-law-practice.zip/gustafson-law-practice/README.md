# Gustafson's Law & Weak Scaling — Practice Repository

Parallel & Distributed Computing Architecture · ungraded comprehensive practice (Tasks 01–25).
Everything is plain Markdown + Python 3 (NumPy, Matplotlib). All numbers in the write-ups are reproducible from the scripts.

## Table of contents
1. [Quick start / execution commands](#1-quick-start--execution-commands)
2. [Core mathematics in one page](#2-core-mathematics-in-one-page)
3. [Architectural synthesis & design guidelines](#3-architectural-synthesis--design-guidelines)
4. [Headline results](#4-headline-results)
5. [Artifact index (Tasks 01–25)](#5-artifact-index)
6. [Honest limitations](#6-honest-limitations)

## 1. Quick start / execution commands

```bash
pip install numpy matplotlib

python3 calculations/compute_all.py                  # all numeric answers (Tasks 06–10, 12, 15–19)
python3 benchmarks/simulator.py                      # Task 21: CSV + overlay plots
python3 benchmarks/weak_scale_bench/weak_bench.py    # Tasks 22–23: measures -> benchmarks/results.csv (~1–2 min)
python3 benchmarks/fit_gustafson.py                  # Task 23: mean/std, least-squares alpha
python3 plots/make_plots.py                          # Task 24: plots/scaling_comparison.{png,pdf}
```
Run commands from the repository root. The committed `results.csv` was measured on a 2-vCPU cloud VM; **re-run on your own multi-core machine** for meaningful scaling data (see §6).

## 2. Core mathematics in one page

| Quantity | Formula |
|---|---|
| Gustafson scaled speedup | S(P) = P − α(P−1) = α + (1−α)P |
| Efficiency | E(P) = 1 − α + α/P → **1−α** |
| Amdahl fixed-size speedup | S_A = 1/(s + (1−s)/P) ≤ 1/s; E_A → 0 like 1/(sP) |
| Bridge identity | α = P·s₁/(1+(P−1)s₁), s₁ = α/(α+(1−α)P) (uniprocessor serial fraction of the scaled problem) |
| Tolerable serial fraction | α_max = (P − S_min)/(P − 1) |
| Sun–Ni | S\* = [s+(1−s)G(P)]/[s+(1−s)G(P)/P]; G=1 Amdahl, G=P Gustafson |
| With communication | S_C = (P − α(P−1))/(1 + C(P)) |
| Isoefficiency | T_o = α(P−1) ⇒ W = Θ(P) |
| Energy ratio | E_P/E_1 = 1 + [α(P−1)/(α+(1−α)P)]·(P_idle/P_act) |

## 3. Architectural synthesis & design guidelines

**When to design around Gustafson (weak scaling):**
* Users want more resolution/accuracy/ensemble members, not the same answer faster (CFD, climate, MD, Monte Carlo, ML data-parallel training with scaled batch).
* Work per process can be kept constant, and per-process communication is constant (nearest-neighbour halo, Task 17) or O(log P) (tree collectives, Task 19).
* Serial parts are absolute fixed costs (start-up, parameter I/O) — keep them O(1) and parallelise anything that grows with N (I/O, mesh generation, tree building: Task 18).

**When Gustafson will mislead you:**
* The problem is fixed (real-time inference on one input, one CAD model): use Amdahl/strong scaling.
* Run time grows with problem size (CG iteration counts, CFL limits, all-to-all, N log N: Tasks 13, 14), or memory binds before time (Sun–Ni, Task 11).
* Imbalance or irregular access dominates (graphs, Task 20).

**Engineering checklist**
1. Measure α on the *parallel* run (profiler), not on one core; report which frame you use (Task 03).
2. Plot weak-scaling efficiency T(1)/T(P), not just speedup.
3. Model communication growth C(P) explicitly (Task 12); look for O(P) or O(√P) terms.
4. Check isoefficiency: a scalable code has W = Θ(P) (Task 14).
5. Budget memory: 3-D grids grow N ∝ P^{1/3} (Task 10).
6. Account for energy: idle cores during serial sections cost P_idle (Task 15).
7. Validate on hardware that has the cores you claim; oversubscription invalidates the model (Task 24).

## 4. Headline results

| Task | Result |
|---|---|
| 06 | α = 0.04: S = 15.4 / 61.48 / 245.8 / 983.08 / 3,932.2 / 15,728.68; E → 0.96 (barely degrades) |
| 07 | α_max = 692/8191 = 0.084483 (8.45 %) |
| 08 | Amdahl 11.47 vs Gustafson 117.84; ratio 10.27× (+927 %) |
| 09 | α = 0.08; S(512) = 471.12, S(2048) = 1,884.24 |
| 10 | (8 B/pt) N_max = 6,501 (64 nodes), 13,003 (512 nodes) |
| 16 | N ∝ P^{1/3}: 8× processors ⇒ 2× N |
| 17 | weak scaling: halo/compute ratio = 6/n constant |
| 19 | tree reduction costs O(log P): E stays 0.9977 up to 10⁶ ranks; flat gather drops to 0.75 at 65k |
| 23–24 | measured S(2) = 1.996; oversubscribed P ≥ 3 degrade (hardware limit) |

## 5. Artifact index

| Task | Deliverable |
|---|---|
| 01 | `theory/task01_scaling_models.md` |
| 02 | `theory/task02_derivation.md` |
| 03 | `theory/task03_serial_invariance.md` |
| 04 | `theory/task04_asymptotic_limits.md` |
| 05 | `theory/task05_historical_ncube.md` |
| 06 | `calculations/task06_parametric_table.md` |
| 07 | `calculations/task07_tolerable_serial.md` |
| 08 | `calculations/task08_cross_divergence.md` |
| 09 | `calculations/task09_multicomponent.md` |
| 10 | `calculations/task10_memory_growth.md` |
| 11 | `theory/task11_sun_ni_comparison.md` |
| 12 | `theory/task12_communication_penalty.md` |
| 13 | `theory/task13_failure_cases.md` |
| 14 | `theory/task14_isoefficiency.md` |
| 15 | `theory/task15_energy_scaling.md` |
| 16 | `calculations/task16_gemm_scaling.md` |
| 17 | `calculations/task17_stencil_scaling.md` |
| 18 | `analysis/task18_nbody_scaling.md` |
| 19 | `analysis/task19_monte_carlo.md` |
| 20 | `analysis/task20_graph_processing.md` |
| 21 | `benchmarks/simulator.py`, `benchmarks/sim_output.csv`, `plots/simulator_overlay.{png,pdf}` |
| 22 | `benchmarks/weak_scale_bench/weak_bench.py`, `benchmarks/weak_scale_bench/README.md` |
| 23 | `benchmarks/results.csv`, `benchmarks/fit_gustafson.py`, `benchmarks/fit_results.json` |
| 24 | `plots/scaling_comparison.{png,pdf}`, `plots/weak_efficiency.png`, `plots/make_plots.py`, `analysis/task24_hardware_audit.md` |
| 25 | this `README.md` |
| support | `calculations/compute_all.py`, `calculations/compute_all_output.txt` |

## 6. Honest limitations

* **Benchmark hardware:** the sandbox that produced `results.csv` has only 2 vCPUs. Only P = 1, 2 are real scaling points; P = 3, 4, 8 are oversubscribed and flagged. Re-run on a multi-core machine and update `analysis/task24_hardware_audit.md` with your `lscpu`.
* **Task 05:** historical speedup figures are quoted from memory — verify against the 1988 papers before citing.
* **Task 09/10/15/18/19:** where the problem statement is silent, the assumptions (phase B treated as serial; bytes per grid point; power values; timing constants) are stated explicitly in each file and are illustrative.
