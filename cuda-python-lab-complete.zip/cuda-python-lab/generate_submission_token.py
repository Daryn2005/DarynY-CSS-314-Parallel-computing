"""The PDF does not include the grader's secret or token protocol."""
if __name__ == "__main__":
    print("A valid hardware-bound HMAC token requires the instructor-provided secret/protocol.")
