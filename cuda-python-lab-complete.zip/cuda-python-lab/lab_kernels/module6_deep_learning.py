import math
from numba import cuda, float32

@cuda.jit
def stable_online_softmax(logits,probs):
    row=cuda.blockIdx.x; t=cuda.threadIdx.x; V=logits.shape[1]
    s=cuda.shared.array(1024,float32)
    if row<logits.shape[0]:
        s[t]=logits[row,t] if t<V else -math.inf; cuda.syncthreads()
        d=cuda.blockDim.x//2
        while d:
            if t<d and s[t+d]>s[t]: s[t]=s[t+d]
            cuda.syncthreads(); d//=2
        m=s[0]
        if t<V: probs[row,t]=math.exp(logits[row,t]-m); s[t]=probs[row,t]
        else: s[t]=0.0
        cuda.syncthreads(); d=cuda.blockDim.x//2
        while d:
            if t<d: s[t]+=s[t+d]
            cuda.syncthreads(); d//=2
        if t<V: probs[row,t]/=s[0]

@cuda.jit
def fused_bias_gelu(x,bias,out):
    i=cuda.grid(1)
    if i<x.size:
        y=x[i]+bias[i%bias.size]
        out[i]=0.5*y*(1+math.tanh(math.sqrt(2/math.pi)*(y+0.044715*y*y*y)))

@cuda.jit
def maxpool2d_with_argmax(x,out,argmax_idx,pool_h,pool_w,stride):
    ow=cuda.blockIdx.x*cuda.blockDim.x+cuda.threadIdx.x; oh=cuda.blockIdx.y*cuda.blockDim.y+cuda.threadIdx.y; b=cuda.blockIdx.z
    if b<out.shape[0] and oh<out.shape[2] and ow<out.shape[3]:
        for c in range(out.shape[1]):
            best=-math.inf; ix=0
            for ph in range(pool_h):
                for pw in range(pool_w):
                    yy=oh*stride+ph; xx=ow*stride+pw; v=x[b,c,yy,xx]
                    if v>best: best=v; ix=yy*x.shape[3]+xx
            out[b,c,oh,ow]=best; argmax_idx[b,c,oh,ow]=ix

@cuda.jit
def batch_norm_1d_forward(x,gamma,beta,eps,out,mean_out,var_out):
    d=cuda.blockIdx.x; t=cuda.threadIdx.x; B,D=x.shape; s=cuda.shared.array(1024,float32)
    if d<D:
        s[t]=x[t,d] if t<B else 0.0; cuda.syncthreads(); k=cuda.blockDim.x//2
        while k:
            if t<k: s[t]+=s[t+k]
            cuda.syncthreads(); k//=2
        mean=s[0]/B
        if t==0: mean_out[d]=mean
        s[t]=(x[t,d]-mean)**2 if t<B else 0.0; cuda.syncthreads(); k=cuda.blockDim.x//2
        while k:
            if t<k: s[t]+=s[t+k]
            cuda.syncthreads(); k//=2
        var=s[0]/B
        if t==0: var_out[d]=var
        if t<B: out[t,d]=gamma[d]*(x[t,d]-mean)/math.sqrt(var+eps)+beta[d]

@cuda.jit
def layer_norm_welford(x,gamma,beta,eps,out):
    row=cuda.blockIdx.x; t=cuda.threadIdx.x; D=x.shape[1]; s=cuda.shared.array(1024,float32)
    if row<x.shape[0]:
        s[t]=x[row,t] if t<D else 0.0; cuda.syncthreads(); k=cuda.blockDim.x//2
        while k:
            if t<k: s[t]+=s[t+k]
            cuda.syncthreads(); k//=2
        mean=s[0]/D; s[t]=(x[row,t]-mean)**2 if t<D else 0.0; cuda.syncthreads(); k=cuda.blockDim.x//2
        while k:
            if t<k: s[t]+=s[t+k]
            cuda.syncthreads(); k//=2
        var=s[0]/D
        if t<D: out[row,t]=(x[row,t]-mean)/math.sqrt(var+eps)*gamma[t]+beta[t]

@cuda.jit
def spmv_csr_kernel(row_ptr,col_indices,values,x,y,num_rows):
    r=cuda.grid(1)
    if r<num_rows:
        s=0.0
        for k in range(row_ptr[r],row_ptr[r+1]): s+=values[k]*x[col_indices[k]]
        y[r]=s

@cuda.jit
def attention_sdpa_tiled(Q,K,V,Out,scale):
    i=cuda.grid(1); S=Q.shape[0]; D=Q.shape[1]
    scores=cuda.local.array(1024,float32)
    if i<S:
        m=-math.inf
        for j in range(S):
            z=0.0
            for d in range(D): z+=Q[i,d]*K[j,d]
            scores[j]=z*scale
            if scores[j]>m: m=scores[j]
        total=0.0
        for j in range(S): scores[j]=math.exp(scores[j]-m); total+=scores[j]
        for d in range(V.shape[1]):
            z=0.0
            for j in range(S): z+=scores[j]/total*V[j,d]
            Out[i,d]=z

@cuda.jit
def fused_rope_embedding(q,cos_table,sin_table,q_rot):
    i=cuda.grid(1); D=q.shape[-1]//2; total=q.size//2
    if i<total:
        d=i%D; pos=(i//D)%q.shape[1]
        flat=q.reshape(q.size); out=q_rot.reshape(q_rot.size)
        a=flat[2*i]; b=flat[2*i+1]; c=cos_table[pos,d]; s=sin_table[pos,d]
        out[2*i]=a*c-b*s; out[2*i+1]=a*s+b*c
