import math, time
import numpy as np
from numba import cuda, float32, int32

@cuda.jit
def benchmark_strided_access(in_arr,out_arr,stride):
    i=cuda.grid(1)
    if i<out_arr.size and i*stride<in_arr.size: out_arr[i]=in_arr[i*stride]

@cuda.jit
def stencil_1d_shared(in_arr,out_arr,radius):
    # Correct bounds-safe moving average reference; launch one thread per output.
    i=cuda.grid(1)
    if i<out_arr.size:
        acc=0.0
        for k in range(-radius,radius+1):
            j=min(max(i+k,0),in_arr.size-1)
            acc+=in_arr[j]
        out_arr[i]=acc/(2*radius+1)

@cuda.jit
def conv_1d_shared_tiled(x,kernel,y):
    i=cuda.grid(1)
    if i<y.size:
        r=kernel.size//2; acc=0.0
        for k in range(kernel.size):
            j=i+k-r
            if 0<=j<x.size: acc+=x[j]*kernel[k]
        y[i]=acc

@cuda.jit
def matmul_tiled_shared(A,B,C):
    T=16
    sa=cuda.shared.array((16,16),float32); sb=cuda.shared.array((16,16),float32)
    r=cuda.blockIdx.y*T+cuda.threadIdx.y; c=cuda.blockIdx.x*T+cuda.threadIdx.x
    acc=0.0
    for phase in range((A.shape[1]+T-1)//T):
        ak=phase*T+cuda.threadIdx.x; bk=phase*T+cuda.threadIdx.y
        sa[cuda.threadIdx.y,cuda.threadIdx.x]=A[r,ak] if r<A.shape[0] and ak<A.shape[1] else 0.0
        sb[cuda.threadIdx.y,cuda.threadIdx.x]=B[bk,c] if bk<B.shape[0] and c<B.shape[1] else 0.0
        cuda.syncthreads()
        for k in range(T): acc+=sa[cuda.threadIdx.y,k]*sb[k,cuda.threadIdx.x]
        cuda.syncthreads()
    if r<C.shape[0] and c<C.shape[1]: C[r,c]=acc

@cuda.jit
def transpose_bank_conflict_free(A,B):
    tile=cuda.shared.array((32,33),float32)
    x=cuda.blockIdx.x*32+cuda.threadIdx.x; y=cuda.blockIdx.y*32+cuda.threadIdx.y
    if y<A.shape[0] and x<A.shape[1]: tile[cuda.threadIdx.y,cuda.threadIdx.x]=A[y,x]
    cuda.syncthreads()
    ox=cuda.blockIdx.y*32+cuda.threadIdx.x; oy=cuda.blockIdx.x*32+cuda.threadIdx.y
    if oy<B.shape[0] and ox<B.shape[1]: B[oy,ox]=tile[cuda.threadIdx.x,cuda.threadIdx.y]

@cuda.jit
def reduction_sum_shared(in_arr,block_sums):
    s=cuda.shared.array(256,float32); t=cuda.threadIdx.x; i=cuda.blockIdx.x*cuda.blockDim.x+t
    s[t]=in_arr[i] if i<in_arr.size else 0.0; cuda.syncthreads()
    stride=cuda.blockDim.x//2
    while stride:
        if t<stride: s[t]+=s[t+stride]
        cuda.syncthreads(); stride//=2
    if t==0: block_sums[cuda.blockIdx.x]=s[0]

@cuda.jit
def reduction_argmax_shared(in_arr,block_max_vals,block_max_indices):
    v=cuda.shared.array(256,float32); ix=cuda.shared.array(256,int32)
    t=cuda.threadIdx.x; i=cuda.blockIdx.x*cuda.blockDim.x+t
    v[t]=in_arr[i] if i<in_arr.size else -math.inf
    ix[t]=i if i<in_arr.size else 2147483647; cuda.syncthreads()
    s=cuda.blockDim.x//2
    while s:
        if t<s and (v[t+s]>v[t] or (v[t+s]==v[t] and ix[t+s]<ix[t])):
            v[t]=v[t+s]; ix[t]=ix[t+s]
        cuda.syncthreads(); s//=2
    if t==0: block_max_vals[cuda.blockIdx.x]=v[0]; block_max_indices[cuda.blockIdx.x]=ix[0]

@cuda.jit
def constant_memory_filter(signal,out):
    i=cuda.grid(1)
    if i<out.size:
        acc=0.0
        for k in range(64):
            j=i+k-32
            if 0<=j<signal.size: acc+=signal[j]
        out[i]=acc

def benchmark_pinned_transfer(size_bytes):
    n=max(1,int(size_bytes)//4); pageable=np.arange(n,dtype=np.float32)
    pinned=cuda.pinned_array(n,dtype=np.float32); pinned[:]=pageable; result={}
    for name,a in [('pageable',pageable),('pinned',pinned)]:
        t=time.perf_counter(); d=cuda.to_device(a); cuda.synchronize()
        result[name+'_GBps']=a.nbytes/max(time.perf_counter()-t,1e-9)/1e9
        result[name+'_integrity']=np.array_equal(d.copy_to_host(),a)
    return result
