from numba import cuda

@cuda.jit
def vector_add_1d(a,b,out):
    i=cuda.grid(1)
    if i<out.size: out[i]=a[i]+b[i]

@cuda.jit
def vector_scale_grid_stride(x,alpha,out):
    i=cuda.grid(1); stride=cuda.gridsize(1)
    while i<x.size:
        out[i]=x[i]*alpha
        i+=stride

@cuda.jit
def matrix_add_2d(A,B,C):
    r=cuda.blockIdx.y*cuda.blockDim.y+cuda.threadIdx.y
    c=cuda.blockIdx.x*cuda.blockDim.x+cuda.threadIdx.x
    if r<C.shape[0] and c<C.shape[1]: C[r,c]=A[r,c]+B[r,c]

@cuda.jit
def matrix_transpose_naive(A,B):
    r=cuda.blockIdx.y*cuda.blockDim.y+cuda.threadIdx.y
    c=cuda.blockIdx.x*cuda.blockDim.x+cuda.threadIdx.x
    if r<A.shape[0] and c<A.shape[1]: B[c,r]=A[r,c]

@cuda.jit
def volume_init_3d(vol,D,H,W):
    x=cuda.blockIdx.x*cuda.blockDim.x+cuda.threadIdx.x
    y=cuda.blockIdx.y*cuda.blockDim.y+cuda.threadIdx.y
    z=cuda.blockIdx.z*cuda.blockDim.z+cuda.threadIdx.z
    if z<D and y<H and x<W: vol[z,y,x]=z*10000+y*100+x

@cuda.jit
def rgb_to_grayscale(img_rgb,img_gray):
    y,x=cuda.grid(2)
    if y<img_gray.shape[0] and x<img_gray.shape[1]:
        img_gray[y,x]=.299*img_rgb[y,x,0]+.587*img_rgb[y,x,1]+.114*img_rgb[y,x,2]

@cuda.jit
def vector_lerp(a,b,t,out):
    i=cuda.grid(1)
    if i<out.size: out[i]=(1-t[i])*a[i]+t[i]*b[i]

@cuda.jit
def vector_threshold(x,thresh,mask):
    i=cuda.grid(1); stride=cuda.gridsize(1)
    while i<x.size:
        mask[i]=1 if x[i]>=thresh else 0
        i+=stride
