import math
from numba import cuda
@cuda.jit
def heat_diffusion_2d_step(u_curr,u_next,alpha,dt,dx,dy):
    i,j=cuda.grid(2); H,W=u_curr.shape
    if i<H and j<W:
        if i==0 or j==0 or i==H-1 or j==W-1: u_next[i,j]=u_curr[i,j]
        else:
            lap=(u_curr[i+1,j]-2*u_curr[i,j]+u_curr[i-1,j])/(dx*dx)+(u_curr[i,j+1]-2*u_curr[i,j]+u_curr[i,j-1])/(dy*dy)
            u_next[i,j]=u_curr[i,j]+alpha*dt*lap

@cuda.jit
def wave_equation_1d_step(u_prev,u_curr,u_next,c,dt,dx):
    i=cuda.grid(1)
    if i<u_curr.size:
        if i==0 or i==u_curr.size-1: u_next[i]=u_curr[i]
        else:
            r=(c*dt/dx)**2
            u_next[i]=2*u_curr[i]-u_prev[i]+r*(u_curr[i+1]-2*u_curr[i]+u_curr[i-1])

@cuda.jit
def nbody_all_pairs(positions,velocities,masses,dt,softening):
    i=cuda.grid(1); n=positions.shape[0]
    if i<n:
        ax=0.0; ay=0.0; az=0.0
        for j in range(n):
            if i!=j:
                dx=positions[j,0]-positions[i,0]; dy=positions[j,1]-positions[i,1]; dz=positions[j,2]-positions[i,2]
                r2=dx*dx+dy*dy+dz*dz+softening*softening; f=masses[j]/(r2*math.sqrt(r2))
                ax+=dx*f; ay+=dy*f; az+=dz*f
        velocities[i,0]+=ax*dt; velocities[i,1]+=ay*dt; velocities[i,2]+=az*dt

@cuda.jit
def gaussian_blur_2d_separable(img_in,img_out,temp_buf,kernel_1d):
    # Horizontal pass; launch this kernel, then a transposed/vertical pass for full separable blur.
    y,x=cuda.grid(2)
    if y<img_in.shape[0] and x<img_in.shape[1]:
        r=kernel_1d.size//2; a=0.0; norm=0.0
        for k in range(kernel_1d.size):
            xx=x+k-r
            if 0<=xx<img_in.shape[1]: a+=img_in[y,xx]*kernel_1d[k]; norm+=kernel_1d[k]
        temp_buf[y,x]=a/norm if norm else 0.0
        img_out[y,x]=temp_buf[y,x]

@cuda.jit
def sobel_edge_detector(img_in,magnitude,orientation):
    y,x=cuda.grid(2); H,W=img_in.shape
    if y<H and x<W:
        gx=0.0; gy=0.0
        for ky in range(-1,2):
            for kx in range(-1,2):
                yy=min(max(y+ky,0),H-1); xx=min(max(x+kx,0),W-1); v=img_in[yy,xx]
                wx=2 if ky==0 else 1; wy=2 if kx==0 else 1
                if kx==-1: gx-=wx*v
                if kx==1: gx+=wx*v
                if ky==-1: gy-=wy*v
                if ky==1: gy+=wy*v
        magnitude[y,x]=math.sqrt(gx*gx+gy*gy); orientation[y,x]=math.atan2(gy,gx)

def monte_carlo_pi_cupy(num_samples):
    import cupy as cp
    x=cp.random.uniform(-1,1,int(num_samples),dtype=cp.float32); y=cp.random.uniform(-1,1,int(num_samples),dtype=cp.float32)
    return float((4*cp.count_nonzero(x*x+y*y<=1)/num_samples).get())

@cuda.jit
def kmeans_assign_clusters(points,centroids,labels,distances):
    i=cuda.grid(1)
    if i<points.shape[0]:
        best=math.inf; idx=0
        for k in range(centroids.shape[0]):
            d=0.0
            for j in range(points.shape[1]):
                z=points[i,j]-centroids[k,j]; d+=z*z
            if d<best: best=d; idx=k
        labels[i]=idx; distances[i]=best

@cuda.jit
def fft_radix2_butterfly_stage(data_re,data_im,stage,N):
    i=cuda.grid(1); half=1<<(stage-1)
    if i<N//2:
        group=i//half; k=i%half; even=group*2*half+k; odd=even+half
        ang=-2*math.pi*k/(2*half); wr=math.cos(ang); wi=math.sin(ang)
        ar=data_re[even]; ai=data_im[even]; br=data_re[odd]; bi=data_im[odd]
        tr=wr*br-wi*bi; ti=wr*bi+wi*br
        data_re[even]=ar+tr; data_im[even]=ai+ti; data_re[odd]=ar-tr; data_im[odd]=ai-ti

@cuda.jit
def mandelbrot_escape_time(out,xmin,xmax,ymin,ymax,max_iter):
    y,x=cuda.grid(2); H,W=out.shape
    if y<H and x<W:
        cr=xmin+(xmax-xmin)*x/(W-1); ci=ymin+(ymax-ymin)*y/(H-1)
        zr=0.0; zi=0.0; count=0
        while count<max_iter and zr*zr+zi*zi<=4:
            tmp=zr*zr-zi*zi+cr; zi=2*zr*zi+ci; zr=tmp; count+=1
        out[y,x]=count
