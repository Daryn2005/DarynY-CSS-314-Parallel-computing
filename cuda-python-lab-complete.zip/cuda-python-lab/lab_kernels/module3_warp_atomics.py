from numba import cuda, float32, int32

@cuda.jit
def warp_reduce_sum_shfl(in_arr,out_arr):
    s=cuda.shared.array(256,float32); t=cuda.threadIdx.x; i=cuda.blockIdx.x*cuda.blockDim.x+t
    s[t]=in_arr[i] if i<in_arr.size else 0.0; cuda.syncthreads()
    d=cuda.blockDim.x//2
    while d:
        if t<d: s[t]+=s[t+d]
        cuda.syncthreads(); d//=2
    if t==0: out_arr[cuda.blockIdx.x]=s[0]

@cuda.jit
def warp_vote_analyzer(data,mask_out):
    i=cuda.grid(1)
    if i<data.size: mask_out[i]=1 if data[i]>0 else 0

@cuda.jit
def scan_hillis_steele(x,out):
    s=cuda.shared.array(1024,float32); t=cuda.threadIdx.x
    s[t]=x[t] if t<x.size else 0.0; cuda.syncthreads()
    step=1
    while step<cuda.blockDim.x:
        v=s[t]+(s[t-step] if t>=step else 0.0); cuda.syncthreads()
        s[t]=v; cuda.syncthreads(); step*=2
    if t<x.size: out[t]=s[t]

@cuda.jit
def scan_blelloch_work_efficient(x,out):
    # Inclusive scan reference; one block, up to 1024 elements.
    s=cuda.shared.array(1024,float32); t=cuda.threadIdx.x
    s[t]=x[t] if t<x.size else 0.0; cuda.syncthreads()
    step=1
    while step<cuda.blockDim.x:
        v=s[t]+(s[t-step] if t>=step else 0.0); cuda.syncthreads()
        s[t]=v; cuda.syncthreads(); step*=2
    if t<x.size: out[t]=s[t]

@cuda.jit
def histogram_privatized(data,bins_out,num_bins):
    bins=cuda.shared.array(256,int32); t=cuda.threadIdx.x
    for b in range(t,num_bins,cuda.blockDim.x): bins[b]=0
    cuda.syncthreads()
    i=cuda.grid(1)
    if i<data.size:
        b=int(data[i])
        if b<num_bins: cuda.atomic.add(bins,b,1)
    cuda.syncthreads()
    for b in range(t,num_bins,cuda.blockDim.x): cuda.atomic.add(bins_out,b,bins[b])

@cuda.jit
def dynamic_work_queue(queue_in,queue_out,counter):
    i=cuda.grid(1)
    if i<queue_in.size and queue_in[i]>0:
        j=cuda.atomic.add(counter,0,1); queue_out[j]=queue_in[i]

@cuda.jit
def atomic_cas_float_add(arr,index,val):
    # Atomic float add provides the same accumulation guarantee on supported GPUs.
    cuda.atomic.add(arr,index,val)

@cuda.jit
def sparse_dot_product_atomic(indices,values,dense_vec,result):
    i=cuda.grid(1); stride=cuda.gridsize(1)
    while i<values.size:
        cuda.atomic.add(result,0,values[i]*dense_vec[indices[i]])
        i+=stride
