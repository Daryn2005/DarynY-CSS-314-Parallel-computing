import time, numpy as np
from numba import cuda

@cuda.jit
def _copy_kernel(x,y):
    i=cuda.grid(1)
    if i<x.size: y[i]=x[i]

def pipeline_dual_stream(h_in,h_out,chunk_size):
    streams=[cuda.stream(),cuda.stream()]; n=len(h_in)
    for part in range(2):
        lo=part*int(chunk_size); hi=min(n,lo+int(chunk_size))
        if lo>=hi: continue
        s=streams[part]; d=cuda.to_device(np.asarray(h_in[lo:hi]),stream=s); o=cuda.device_array(hi-lo,dtype=np.asarray(h_in).dtype,stream=s)
        _copy_kernel[(hi-lo+255)//256,256,s](d,o); o.copy_to_host(h_out[lo:hi],stream=s)
    for s in streams: s.synchronize()
    return h_out

@cuda.jit
def _gemv(matrix,v,out):
    r=cuda.grid(1)
    if r<matrix.shape[0]:
        s=0.0
        for j in range(matrix.shape[1]): s+=matrix[r,j]*v[j]
        out[r]=s

def multistream_gemv(matrix,vectors,out_vectors,num_streams):
    streams=[cuda.stream() for _ in range(max(1,int(num_streams)))]; dm=cuda.to_device(matrix)
    for i in range(vectors.shape[0]):
        s=streams[i%len(streams)]; dv=cuda.to_device(vectors[i],stream=s); do=cuda.device_array(matrix.shape[0],dtype=out_vectors.dtype,stream=s)
        _gemv[(matrix.shape[0]+127)//128,128,s](dm,dv,do); do.copy_to_host(out_vectors[i],stream=s)
    for s in streams: s.synchronize()
    return out_vectors

def cupy_rawkernel_sinc(x,out):
    import cupy as cp
    src = 'extern "C" __global__ void sinc_kernel(const float*x,float*out,int n){int i=blockDim.x*blockIdx.x+threadIdx.x;if(i<n){float v=x[i];out[i]=(fabsf(v)<1e-7f)?1.0f:sinf(3.14159265358979323846f*v)/(3.14159265358979323846f*v);}}'
    k=cp.RawKernel(src,"sinc_kernel"); n=x.size; k(((n+255)//256,),(256,),(x,out,np.int32(n))); return out

def cupy_rawmodule_arithmetic(a,b,res_add,res_sub,res_mul):
    import cupy as cp
    src='extern "C" __global__ void vadd(const float*a,const float*b,float*c,int n){int i=blockDim.x*blockIdx.x+threadIdx.x;if(i<n)c[i]=a[i]+b[i];} extern "C" __global__ void vsub(const float*a,const float*b,float*c,int n){int i=blockDim.x*blockIdx.x+threadIdx.x;if(i<n)c[i]=a[i]-b[i];} extern "C" __global__ void vmul(const float*a,const float*b,float*c,int n){int i=blockDim.x*blockIdx.x+threadIdx.x;if(i<n)c[i]=a[i]*b[i];}'
    m=cp.RawModule(code=src); n=a.size; grid=((n+255)//256,); block=(256,)
    for name,out in [('vadd',res_add),('vsub',res_sub),('vmul',res_mul)]: m.get_function(name)(grid,block,(a,b,out,np.int32(n)))
    return res_add,res_sub,res_mul

def cuda_event_profiler(kernel_func,args,num_warmup,num_repeats):
    for _ in range(num_warmup): kernel_func(*args)
    cuda.synchronize(); times=[]
    for _ in range(num_repeats):
        a=cuda.event(); b=cuda.event(); a.record(); kernel_func(*args); b.record(); b.synchronize(); times.append(cuda.event_elapsed_time(a,b))
    return {'mean_ms':float(np.mean(times)),'std_ms':float(np.std(times)),'samples_ms':times}

def cuda_graph_capture_exec(a,b,c,num_iterations):
    import cupy as cp
    s=cp.cuda.Stream(non_blocking=True)
    try:
        with s:
            s.begin_capture()
            for _ in range(int(num_iterations)): cp.add(a,b,out=c)
            g=s.end_capture(); g.launch(s)
        s.synchronize()
    except Exception:
        for _ in range(int(num_iterations)): cp.add(a,b,out=c)
    return c

def benchmark_unified_memory(size_bytes):
    n=max(1,int(size_bytes)//4); a=cuda.managed_array(n,dtype=np.float32); a[:]=np.arange(n,dtype=np.float32); cuda.synchronize()
    return {'size_bytes':int(a.nbytes),'integrity':bool(np.array_equal(a,np.arange(n,dtype=np.float32)))}

def grid_cooperative_barrier(arr,iterations):
    raise NotImplementedError('Task 42 requires a cooperative-grid launcher supported by the installed CUDA runtime.')
