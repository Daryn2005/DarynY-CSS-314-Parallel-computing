"""Environment smoke test; full grading requires the official instructor tests."""
if __name__ == "__main__":
    from numba import cuda
    print("CUDA available:", cuda.is_available())
    if cuda.is_available():
        print("GPU:", cuda.get_current_device().name)
    else:
        print("Select a GPU runtime in Google Colab.")
