# CUDA Python Lab — 50 Tasks
This is a reference implementation package based on the provided PDF. Use Google Colab with a CUDA GPU and install requirements with `pip install -r requirements.txt`.

Modules map to the PDF tasks: 1–8 execution model, 9–17 memory, 18–25 warp/atomics, 26–34 scientific computing, 35–42 streams/CuPy, 43–50 deep learning.

Hardware-specific performance requirements cannot be guaranteed by source code alone. Task 42 cooperative-grid synchronization and the PDF's HMAC submission token require instructor/runtime-specific support and are documented as such.
