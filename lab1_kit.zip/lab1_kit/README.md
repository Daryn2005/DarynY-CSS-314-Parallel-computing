# Amdahl Reality Gap — Lab Kit

This kit gives you working, compiling code for every phase of the worksheet.
**You still have to run it on your own laptop** — the instructor's integrity
checks are specifically looking for timings, a checksum, and a hardware dump
that come from real execution, which nothing but your own machine can produce.

## Files
- `collatz.c` — full source: sequential baseline, parallel scaling, false
  sharing experiment (naive/padded/reduction), scheduling sweep. Compiles
  clean with `-Wall -Wextra`, verified on a sandbox machine (checksum was
  identical across every mode, confirming correctness).
- `run_all.sh` — drives the whole benchmark sequence and logs raw output.
- `results_template.csv` — column layout matching Tables 1–3; fill with your
  real numbers.
- `plot_speedup.py` — once you've filled in your Table 1 timings, generates
  `speedup_plot.png` (S_emp vs S_theo vs linear ideal) and prints the derived
  `p`.

## Your machine: ASUS TUF Gaming F15 (FX506), Core i5-11400H
- 6 physical cores, 12 logical threads (classic 2-way SMT/hyperthreading —
  no Performance/Efficiency hybrid split, so Q2's answer is the "plain"
  hyperthreading case: every pair of logical threads shares one physical
  core's execution ports, L1/L2 cache, and fetch/decode front end).
- Your thread ceiling is **12**, not 16. In Table 1, replace the
  `k = 16 (or max)` row with **k = 12** — `run_all.sh` below already does
  this automatically.
- Recommended k values to actually run: **1, 2, 4, 8, 12**.

### Toolchain on Windows
`gcc -fopenmp` doesn't come with plain Windows. Use one of:
- **WSL2 (recommended)** — gives you a real Linux environment, and its
  `lscpu` will read your actual CPU, matching what the worksheet expects:
  ```powershell
  wsl --install -d Ubuntu
  ```
  Reboot if prompted, then inside the Ubuntu shell:
  ```bash
  sudo apt update && sudo apt install -y build-essential gcc
  ```
  WSL2 exposes all 6 cores/12 threads to Linux by default, so `nproc` and
  `lscpu` inside WSL will correctly show 12.
- **MSYS2/MinGW-w64** (native Windows binary) if you'd rather not use WSL —
  install MSYS2, then `pacman -S mingw-w64-x86_64-gcc`, and compile from the
  MSYS2 MinGW64 shell. `lscpu` isn't available here; use the PowerShell
  `Get-CimInstance` command from Step 2 below instead for `hw_info.txt`.

## Step 1 — Compute your unique N
```
N = 10,000,000 + (last 4 digits of your Student ID * 1000)
```

## Step 2 — Capture your hardware dump (Step 1.1 of the worksheet)
```bash
# Linux
lscpu > hw_info.txt
# macOS
sysctl -a | grep -E "machdep.cpu|hw.ncpu|hw.l" > hw_info.txt
# Windows PowerShell
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors | Format-List > hw_info.txt
```
Also note `omp_get_max_threads()` — you can get it by compiling and running:
```bash
echo '#include <omp.h>
#include <stdio.h>
int main(){printf("%d\n", omp_get_max_threads()); return 0;}' > maxt.c
gcc -fopenmp maxt.c -o maxt && ./maxt
```

## Step 3 — Run the sweep on YOUR machine
```bash
chmod +x run_all.sh
./run_all.sh <YOUR_N> 12
```
(12 = your logical thread count. The script runs k = 1, 2, 4, 8 from the
standard sweep, then adds a k = 12 run automatically for the "max" row.)
Close browsers/IDEs/streaming audio first (the worksheet's isolation rule).
This produces `seq_runs.log`, `parallel_runs.log`, `falsesharing.log`,
`scheduling.log` — transcribe the real times from these into
`results_template.csv` (rename to `results.csv` when done) and into the
worksheet's Tables 1–3.

## Step 4 — Derive p and plot
Edit the `T_SEQ` / `T_K` values at the top of `plot_speedup.py` with your
actual Table 1 numbers, then:
```bash
python3 plot_speedup.py
```
This prints your derived `p` and writes `speedup_plot.png`.

## Step 5 — Answering Q1–Q4
The code and this kit don't answer these for you — they require your actual
numbers — but here's what each answer needs to reference, so you know what to
look for in your own data:

- **Q1 (False sharing root cause):** your CPU's L1 cache line size (from
  `hw_info.txt`), and the fact that `hit_count[]` is a small array whose
  entries almost certainly share one or two 64-byte cache lines. Under
  MESI/MOESI, every write by one thread invalidates that line in every other
  core's cache, forcing a re-fetch over the coherence bus before the next
  write — even though each thread touches a logically distinct variable.
  Your evidence is the naive-vs-padded/reduction time gap you measured.
- **Q2 (SMT ceiling):** on your i5-11400H, compare S_emp(6) to S_emp(12) —
  that's the exact point where you cross from physical cores into
  hyperthreaded (SMT) territory, since this chip has no E-cores to complicate
  the picture. Each pair of logical threads (0&6, 1&7, etc. depending on OS
  mapping) shares one physical core's ALUs/execution ports, L1/L2 cache, and
  instruction fetch/decode front end. Expect the k=6→12 jump in S_emp to be
  much smaller than the k=1→2 or k=2→4 jumps — report whether that's what you
  actually measured, and by how much it fell short of doubling.
- **Q3 (Empirical vs theoretical divergence):** state the `p` your script
  printed. Two real factors Amdahl's equation omits that you can point to
  from your own run: (a) memory bandwidth/cache contention growing with
  thread count, and (b) OpenMP's fork/join and reduction synchronization
  overhead, which is fixed-cost per parallel region and eats a larger
  fraction of shrinking per-thread work as k grows.
- **Q4 (Scheduling trade-off):** compare your own `dynamic,100` vs
  `dynamic,10000` vs `static` times from Table 3 — Collatz workload is
  imbalanced (some integers take far more steps), so small chunks balance
  load but add queue-locking overhead per chunk; large chunks cut that
  overhead but let one slow chunk stall a thread at the barrier. Report
  whichever chunk size was fastest on your machine and explain the trade-off
  direction it implies.

## What NOT to do
Don't hand-copy example numbers from anywhere (including this kit) into your
tables — the checksum and timings are tied to your specific N and hardware,
and mismatched/implausible-variance data is exactly what the rubric penalizes.
