/*
 * collatz.c — Amdahl Reality Gap Lab
 *
 * Implements:
 *   Phase 2: sequential baseline (collatz max steps + checksum)
 *   Phase 3: OpenMP parallel scaling over k threads
 *   Phase 4A: false sharing experiment (naive per-thread array vs
 *             reduction / padded counters)
 *   Phase 4B: loop scheduling experiment (static / static,chunk /
 *             dynamic,chunk / guided)
 *
 * Compile:
 *   gcc -O2 -fopenmp collatz.c -o collatz
 *
 * Usage:
 *   ./collatz seq        <N>
 *   ./collatz parallel   <N> <threads> [schedule] [chunk]
 *       schedule in {static, dynamic, guided}  (default: static)
 *       chunk    integer chunk size             (default: 0 = runtime default)
 *   ./collatz falsesharing <N> <threads> <naive|padded|reduction>
 *   ./collatz scheduling  <N> <threads>
 *       (runs all five scheduling variants from Table 2 in one pass
 *        and prints a CSV-ready line for each)
 *
 * All timings use omp_get_wtime(). Checksum is the sum of all stopping
 * times modulo 1,000,000,007, used as an anti-cheat / correctness check —
 * it must be IDENTICAL across every implementation variant for the same N.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <omp.h>

#define MOD 1000000007ULL

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

/* ---------- Phase 2: sequential baseline ---------- */
static void run_seq(uint64_t N) {
    uint32_t max_steps = 0;
    uint64_t max_i = 0;
    uint64_t checksum = 0;

    double t0 = omp_get_wtime();
    for (uint64_t i = 1; i <= N; i++) {
        uint32_t s = collatz_steps(i);
        if (s > max_steps) { max_steps = s; max_i = i; }
        checksum = (checksum + s) % MOD;
    }
    double t1 = omp_get_wtime();

    printf("mode=seq N=%llu time_s=%.6f max_steps=%u max_i=%llu checksum=%llu\n",
           (unsigned long long)N, t1 - t0, max_steps,
           (unsigned long long)max_i, (unsigned long long)checksum);
}

/* ---------- Phase 3: parallel scaling ---------- */
static void run_parallel(uint64_t N, int threads, const char *sched, int chunk) {
    omp_set_num_threads(threads);

    uint32_t max_steps = 0;
    uint64_t checksum = 0;

    double t0 = omp_get_wtime();

    if (sched && strcmp(sched, "dynamic") == 0) {
        #pragma omp parallel for schedule(dynamic, chunk > 0 ? chunk : 1) \
                reduction(max:max_steps) reduction(+:checksum)
        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            if (s > max_steps) max_steps = s;
            checksum = (checksum + s) % MOD;
        }
    } else if (sched && strcmp(sched, "guided") == 0) {
        #pragma omp parallel for schedule(guided) \
                reduction(max:max_steps) reduction(+:checksum)
        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            if (s > max_steps) max_steps = s;
            checksum = (checksum + s) % MOD;
        }
    } else if (chunk > 0) {
        #pragma omp parallel for schedule(static, chunk) \
                reduction(max:max_steps) reduction(+:checksum)
        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            if (s > max_steps) max_steps = s;
            checksum = (checksum + s) % MOD;
        }
    } else {
        #pragma omp parallel for schedule(static) \
                reduction(max:max_steps) reduction(+:checksum)
        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            if (s > max_steps) max_steps = s;
            checksum = (checksum + s) % MOD;
        }
    }

    double t1 = omp_get_wtime();

    printf("mode=parallel N=%llu threads=%d schedule=%s chunk=%d time_s=%.6f "
           "max_steps=%u checksum=%llu\n",
           (unsigned long long)N, threads, sched ? sched : "static", chunk,
           t1 - t0, max_steps, (unsigned long long)checksum);
}

/* ---------- Phase 4A: false sharing experiment ---------- */

/* padded counter: forces each thread's slot onto its own 64B cache line */
typedef struct {
    long count;
    char pad[64 - sizeof(long)];
} PaddedCounter;

static void run_falsesharing(uint64_t N, int threads, const char *variant) {
    omp_set_num_threads(threads);
    long total_hits = 0;
    double t0, t1;

    if (strcmp(variant, "naive") == 0) {
        /* Variant 1: adjacent ints in one array -> same cache line(s) ->
           every increment invalidates other threads' cached copies. */
        long *hit_count = calloc(threads, sizeof(long));
        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > 100) {
                hit_count[omp_get_thread_num()]++;
            }
        }
        t1 = omp_get_wtime();
        for (int t = 0; t < threads; t++) total_hits += hit_count[t];
        free(hit_count);

    } else if (strcmp(variant, "padded") == 0) {
        /* Variant 2a: each thread's counter padded to its own cache line. */
        PaddedCounter *counters = calloc(threads, sizeof(PaddedCounter));
        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > 100) {
                counters[omp_get_thread_num()].count++;
            }
        }
        t1 = omp_get_wtime();
        for (int t = 0; t < threads; t++) total_hits += counters[t].count;
        free(counters);

    } else if (strcmp(variant, "reduction") == 0) {
        /* Variant 2b: OpenMP reduction, no shared array at all. */
        t0 = omp_get_wtime();
        #pragma omp parallel for schedule(static) reduction(+:total_hits)
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > 100) total_hits++;
        }
        t1 = omp_get_wtime();

    } else {
        fprintf(stderr, "unknown variant '%s' (use naive|padded|reduction)\n", variant);
        exit(1);
    }

    double elapsed = t1 - t0;
    double throughput = (double)N / elapsed;
    printf("mode=falsesharing N=%llu threads=%d variant=%s time_s=%.6f "
           "hits=%ld throughput_iter_per_s=%.1f\n",
           (unsigned long long)N, threads, variant, elapsed, total_hits, throughput);
}

/* ---------- Phase 4B: scheduling sweep (Table 2) ---------- */
static void run_scheduling_sweep(uint64_t N, int threads) {
    omp_set_num_threads(threads);
    struct { const char *label; int dynamic_kind; int chunk; } variants[] = {
        {"static_default",   0, 0},
        {"static_1000",      0, 1000},
        {"dynamic_100",      1, 100},
        {"dynamic_10000",    1, 10000},
        {"guided",           2, 0},
    };

    for (int v = 0; v < 5; v++) {
        uint32_t max_steps = 0;
        uint64_t checksum = 0;
        double t0 = omp_get_wtime();

        if (variants[v].dynamic_kind == 1) {
            int chunk = variants[v].chunk;
            #pragma omp parallel for schedule(dynamic, chunk) \
                    reduction(max:max_steps) reduction(+:checksum)
            for (uint64_t i = 1; i <= N; i++) {
                uint32_t s = collatz_steps(i);
                if (s > max_steps) max_steps = s;
                checksum = (checksum + s) % MOD;
            }
        } else if (variants[v].dynamic_kind == 2) {
            #pragma omp parallel for schedule(guided) \
                    reduction(max:max_steps) reduction(+:checksum)
            for (uint64_t i = 1; i <= N; i++) {
                uint32_t s = collatz_steps(i);
                if (s > max_steps) max_steps = s;
                checksum = (checksum + s) % MOD;
            }
        } else if (variants[v].chunk > 0) {
            int chunk = variants[v].chunk;
            #pragma omp parallel for schedule(static, chunk) \
                    reduction(max:max_steps) reduction(+:checksum)
            for (uint64_t i = 1; i <= N; i++) {
                uint32_t s = collatz_steps(i);
                if (s > max_steps) max_steps = s;
                checksum = (checksum + s) % MOD;
            }
        } else {
            #pragma omp parallel for schedule(static) \
                    reduction(max:max_steps) reduction(+:checksum)
            for (uint64_t i = 1; i <= N; i++) {
                uint32_t s = collatz_steps(i);
                if (s > max_steps) max_steps = s;
                checksum = (checksum + s) % MOD;
            }
        }

        double t1 = omp_get_wtime();
        printf("mode=scheduling N=%llu threads=%d variant=%s time_s=%.6f "
               "max_steps=%u checksum=%llu\n",
               (unsigned long long)N, threads, variants[v].label,
               t1 - t0, max_steps, (unsigned long long)checksum);
    }
}

/* ---------- main / CLI ---------- */
int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr,
            "Usage:\n"
            "  %s seq <N>\n"
            "  %s parallel <N> <threads> [static|dynamic|guided] [chunk]\n"
            "  %s falsesharing <N> <threads> <naive|padded|reduction>\n"
            "  %s scheduling <N> <threads>\n",
            argv[0], argv[0], argv[0], argv[0]);
        return 1;
    }

    const char *mode = argv[1];
    uint64_t N = strtoull(argv[2], NULL, 10);

    if (strcmp(mode, "seq") == 0) {
        run_seq(N);
    } else if (strcmp(mode, "parallel") == 0) {
        if (argc < 4) { fprintf(stderr, "parallel needs <threads>\n"); return 1; }
        int threads = atoi(argv[3]);
        const char *sched = (argc >= 5) ? argv[4] : "static";
        int chunk = (argc >= 6) ? atoi(argv[5]) : 0;
        run_parallel(N, threads, sched, chunk);
    } else if (strcmp(mode, "falsesharing") == 0) {
        if (argc < 5) { fprintf(stderr, "falsesharing needs <threads> <variant>\n"); return 1; }
        int threads = atoi(argv[3]);
        run_falsesharing(N, threads, argv[4]);
    } else if (strcmp(mode, "scheduling") == 0) {
        if (argc < 4) { fprintf(stderr, "scheduling needs <threads>\n"); return 1; }
        int threads = atoi(argv[3]);
        run_scheduling_sweep(N, threads);
    } else {
        fprintf(stderr, "unknown mode '%s'\n", mode);
        return 1;
    }
    return 0;
}
