#!/usr/bin/env bash
# run_all.sh — drives the full Amdahl Reality Gap benchmark sweep.
# Run this on YOUR OWN laptop, after computing your own N (see README.md).
# Usage: ./run_all.sh <N> <MAX_PHYSICAL_THREADS>

set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: $0 <N> <MAX_THREADS>"
  echo "  N           = 10000000 + (last 4 digits of your Student ID * 1000)"
  echo "  MAX_THREADS = your omp_get_max_threads() value"
  exit 1
fi

N=$1
MAXT=$2
OUT=results.csv
BIN=./collatz

echo "Compiling..."
gcc -O2 -fopenmp -Wall -Wextra collatz.c -o collatz

echo "mode,N,threads,schedule,chunk,variant,time_s,max_steps,checksum,hits,throughput" > "$OUT"

echo "== Phase 2: sequential baseline (3 runs, discard run 1) =="
for run in 1 2 3; do
  echo "  run $run..."
  $BIN seq "$N" | tee -a seq_runs.log
done

echo "== Phase 3: parallel scaling k = 1,2,4,8,16 (capped at $MAXT) =="
RAN_MAXT=0
for k in 1 2 4 8 16; do
  if [ "$k" -le "$MAXT" ]; then
    echo "  threads=$k (run 1 of 3, discard)..."
    $BIN parallel "$N" "$k" static
    echo "  threads=$k (run 2 of 3)..."
    $BIN parallel "$N" "$k" static | tee -a parallel_runs.log
    echo "  threads=$k (run 3 of 3)..."
    $BIN parallel "$N" "$k" static | tee -a parallel_runs.log
    [ "$k" -eq "$MAXT" ] && RAN_MAXT=1
  fi
done
# The worksheet's Table 1 wants a "k=16 (or max)" row. If your machine's
# thread ceiling isn't one of 1/2/4/8/16 (e.g. 12 logical threads), run it
# explicitly here so that row is covered.
if [ "$RAN_MAXT" -eq 0 ]; then
  echo "  threads=$MAXT (max on this machine) (run 1 of 3, discard)..."
  $BIN parallel "$N" "$MAXT" static
  echo "  threads=$MAXT (run 2 of 3)..."
  $BIN parallel "$N" "$MAXT" static | tee -a parallel_runs.log
  echo "  threads=$MAXT (run 3 of 3)..."
  $BIN parallel "$N" "$MAXT" static | tee -a parallel_runs.log
fi

echo "== Phase 4A: false sharing (naive vs padded vs reduction) at MAX_THREADS=$MAXT =="
$BIN falsesharing "$N" "$MAXT" naive     | tee -a falsesharing.log
$BIN falsesharing "$N" "$MAXT" padded    | tee -a falsesharing.log
$BIN falsesharing "$N" "$MAXT" reduction | tee -a falsesharing.log

echo "== Phase 4B: scheduling sweep at MAX_THREADS=$MAXT =="
$BIN scheduling "$N" "$MAXT" | tee -a scheduling.log

echo ""
echo "Done. Raw outputs are in seq_runs.log, parallel_runs.log, falsesharing.log,"
echo "scheduling.log. Transcribe the real numbers from these logs into"
echo "results.csv and Table 1 / Table 2 / Table 3 of the worksheet."
echo "IMPORTANT: run each benchmark on an otherwise-idle machine (close"
echo "browsers/IDEs/streaming audio) and expect run-to-run variance --"
echo "that variance is itself evidence the timings are real."
