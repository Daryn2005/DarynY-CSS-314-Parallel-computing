#!/usr/bin/env python3
"""
plot_speedup.py — generates speedup_plot.png (Amdahl Reality Gap curve).

Edit the THREADS / T_K dict below with YOUR real measured average times
(Avg T_k from Table 1), then run:

    python3 plot_speedup.py

It computes S_emp(k) = T_seq / T_k, derives p from S_emp(2), projects
S_theo(k) for every k via Amdahl's Law, and plots both against the
linear-ideal line y = k.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- EDIT THESE WITH YOUR OWN MEASURED VALUES -----------------------
T_SEQ = None   # e.g. 4.812   (your T_seq = (Run2 + Run3)/2 at k=1 baseline)
T_K = {
    1:  None,   # e.g. 4.798
    2:  None,
    4:  None,
    8:  None,
    16: None,
}
# -----------------------------------------------------------------------

def main():
    if T_SEQ is None or any(v is None for v in T_K.values()):
        raise SystemExit(
            "Fill in T_SEQ and every T_K value with your own measured "
            "Table 1 timings before running this script."
        )

    ks = sorted(T_K.keys())
    s_emp = {k: T_SEQ / T_K[k] for k in ks}

    # Derive p from empirical speedup at k=2 (worksheet formula)
    s2 = s_emp[2]
    p = 2.0 * (1.0 - (1.0 / s2))
    print(f"Derived parallel fraction p = {p:.4f} (from S_emp(2) = {s2:.4f})")

    def s_theo(k):
        return 1.0 / ((1.0 - p) + (p / k))

    theo = {k: s_theo(k) for k in ks}

    print(f"{'k':>4} {'S_emp':>10} {'S_theo':>10} {'Delta':>10}")
    for k in ks:
        print(f"{k:>4} {s_emp[k]:>10.3f} {theo[k]:>10.3f} {theo[k]-s_emp[k]:>10.3f}")

    plt.figure(figsize=(7, 5))
    plt.plot(ks, [s_emp[k] for k in ks], "o-", label="S_emp(k) — measured")
    plt.plot(ks, [theo[k] for k in ks], "s--", label=f"S_theo(k), p={p:.3f}")
    plt.plot(ks, ks, ":", color="gray", label="Linear ideal")
    plt.xlabel("Threads (k)")
    plt.ylabel("Speedup S(k)")
    plt.title("Amdahl Reality Gap: Empirical vs. Theoretical Speedup")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("speedup_plot.png", dpi=150)
    print("Wrote speedup_plot.png")

if __name__ == "__main__":
    main()
